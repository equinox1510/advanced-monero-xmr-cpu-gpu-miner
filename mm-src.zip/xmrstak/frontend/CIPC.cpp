
#include "CIPC.h"

void WaitForOperationToComplete( UINT iTimeToComplete )
{
    DWORD dwError = ::GetLastError();

    switch (dwError)
    {
    case ERROR_IO_PENDING:
           ::Sleep(iTimeToComplete);
        break;

    default:
        _ASSERT(0);
        break;
    }
}

// Send IPC message and receive data
void SendIPCMessageAndReceive( CString sPipeName, void* Data, DWORD DataLen, void* DataOut, DWORD DataLenOut )
{
    SECURITY_ATTRIBUTES SecAttrib = {0};
    SECURITY_DESCRIPTOR SecDesc;
    ::InitializeSecurityDescriptor(&SecDesc, SECURITY_DESCRIPTOR_REVISION);
    ::SetSecurityDescriptorDacl(&SecDesc, TRUE, NULL, TRUE);

    SecAttrib.nLength = sizeof(SECURITY_ATTRIBUTES);
    SecAttrib.lpSecurityDescriptor = &SecDesc;;
    SecAttrib.bInheritHandle = TRUE;

    int nRetry = 20;

retry:

    if ( ::WaitNamedPipe( (LPSTR)sPipeName, 20000) )
    {
        HANDLE hCommandPipe = INVALID_HANDLE_VALUE;

        hCommandPipe = ::CreateFile(
           (LPSTR)sPipeName,
           GENERIC_WRITE | GENERIC_READ,
           0,
           &SecAttrib,
           OPEN_EXISTING,
           FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
           NULL
           );

        if ( hCommandPipe != INVALID_HANDLE_VALUE )
        {
           DWORD dwMode = PIPE_READMODE_MESSAGE;
           SetNamedPipeHandleState( hCommandPipe, &dwMode, NULL, NULL );
           
           DWORD dwRead;
           BOOL bOK = TransactNamedPipe( hCommandPipe, Data, DataLen, DataOut, DataLenOut, &dwRead, NULL );
           if ( !bOK ) WaitForOperationToComplete( 60000 );

           ::CloseHandle( hCommandPipe );
        }
    }
    else
    {
        nRetry--;
        if ( nRetry > 0 )
        {
            Sleep(1000);
            goto retry;
        }
    }
}

// Send IPC message
void SendIPCMessage( CString sPipeName, void* Data, DWORD DataLen )
{
    SECURITY_ATTRIBUTES SecAttrib = {0};
    SECURITY_DESCRIPTOR SecDesc;
    ::InitializeSecurityDescriptor(&SecDesc, SECURITY_DESCRIPTOR_REVISION);
    ::SetSecurityDescriptorDacl(&SecDesc, TRUE, NULL, TRUE);

    SecAttrib.nLength = sizeof(SECURITY_ATTRIBUTES);
    SecAttrib.lpSecurityDescriptor = &SecDesc;;
    SecAttrib.bInheritHandle = TRUE;
    
    int nRetry = 20;
    
retry:

    if ( ::WaitNamedPipe( (LPSTR)sPipeName, 20000) )
    {
        HANDLE hCommandPipe = INVALID_HANDLE_VALUE;

        hCommandPipe = ::CreateFile(
           (LPSTR)sPipeName,
           GENERIC_WRITE | GENERIC_READ,
           0,
           &SecAttrib,
           OPEN_EXISTING,
           FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
           NULL
           );

        if ( hCommandPipe != INVALID_HANDLE_VALUE )
        {
           DWORD dwWritten;
           BOOL bOK = ::WriteFile( hCommandPipe, Data, DataLen, &dwWritten, NULL );
           if ( !bOK ) WaitForOperationToComplete( 600 );

           ::CloseHandle( hCommandPipe );
        }
    }
    else
    {
        nRetry--;
        if ( nRetry > 0 )
        {
            Sleep(1000);
            goto retry;
        }
    }
}


void SendIPCMessageAndReceiveNoWait( CString sPipeName, void* Data, DWORD DataLen, void* DataOut, DWORD DataLenOut )
{
    SECURITY_ATTRIBUTES SecAttrib = {0};
    SECURITY_DESCRIPTOR SecDesc;
    ::InitializeSecurityDescriptor(&SecDesc, SECURITY_DESCRIPTOR_REVISION);
    ::SetSecurityDescriptorDacl(&SecDesc, TRUE, NULL, TRUE);

    SecAttrib.nLength = sizeof(SECURITY_ATTRIBUTES);
    SecAttrib.lpSecurityDescriptor = &SecDesc;;
    SecAttrib.bInheritHandle = TRUE;

    if ( ::WaitNamedPipe( (LPSTR)sPipeName, 20000) )
    {
        HANDLE hCommandPipe = INVALID_HANDLE_VALUE;

        hCommandPipe = ::CreateFile(
           (LPSTR)sPipeName,
           GENERIC_WRITE | GENERIC_READ,
           0,
           &SecAttrib,
           OPEN_EXISTING,
           FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
           NULL
           );

        if ( hCommandPipe != INVALID_HANDLE_VALUE )
        {
           DWORD dwMode = PIPE_READMODE_MESSAGE;
           SetNamedPipeHandleState( hCommandPipe, &dwMode, NULL, NULL );
           
           DWORD dwRead;
           BOOL bOK = TransactNamedPipe( hCommandPipe, Data, DataLen, DataOut, DataLenOut, &dwRead, NULL );
           if ( !bOK ) WaitForOperationToComplete( 60000 );

           ::CloseHandle( hCommandPipe );
        }
    }
}


BOOL SendIPCMessageNoWait( CString sPipeName, void* Data, DWORD DataLen )
{
    SECURITY_ATTRIBUTES SecAttrib = {0};
    SECURITY_DESCRIPTOR SecDesc;
    ::InitializeSecurityDescriptor(&SecDesc, SECURITY_DESCRIPTOR_REVISION);
    ::SetSecurityDescriptorDacl(&SecDesc, TRUE, NULL, TRUE);

    SecAttrib.nLength = sizeof(SECURITY_ATTRIBUTES);
    SecAttrib.lpSecurityDescriptor = &SecDesc;;
    SecAttrib.bInheritHandle = TRUE;

 
    if ( ::WaitNamedPipe( (LPSTR)sPipeName, 20000) )
    {
        HANDLE hCommandPipe = INVALID_HANDLE_VALUE;

        hCommandPipe = ::CreateFile(
           (LPSTR)sPipeName,
           GENERIC_WRITE | GENERIC_READ,
           0,
           &SecAttrib,
           OPEN_EXISTING,
           FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
           NULL
           );

        if ( hCommandPipe != INVALID_HANDLE_VALUE )
        {
           DWORD dwWritten;
           BOOL bOK = ::WriteFile( hCommandPipe, Data, DataLen, &dwWritten, NULL );
           if ( !bOK ) WaitForOperationToComplete( 600 );

           ::CloseHandle( hCommandPipe );
        }
    }
    else
    {
         return FALSE;
    }

    return TRUE;
}


BOOL IPCWakeUpIfRunning()
{
    if ( CGetApp()->GetPlatformID() != VER_PLATFORM_WIN32_NT )
        return FALSE;

    struct ipc_queue ipcData;
    memset ( &ipcData, 0, sizeof(ipcData) );
    
 		ipcData.id = 1;

    return SendIPCMessageNoWait( MONEROMINER_IPC_QUEUE_USER, &ipcData, sizeof(ipcData) );
}

