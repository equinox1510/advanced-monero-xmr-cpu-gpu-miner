
#include "CSkinXpMenu.h"
#include "CIni.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CSkinXPMenu::CSkinXPMenu() : m_bDrawOldStyle( FALSE ),
													   m_bDrawIconShadows( FALSE )
{
        TCHAR dataPath[MAX_PATH]={0};
    		::SHGetSpecialFolderPath( NULL, dataPath, CSIDL_APPDATA, FALSE );

    		// Load settings file
    		CString strSettings = dataPath;
    		strSettings += "\\MoneroMiner\\settings.ini";
    		CIni m_SettingsFile( strSettings );

    		CString strCurrentSkin = GetModulePath();
    		strCurrentSkin += "\\Skins\\"; //"
    		strCurrentSkin += m_SettingsFile.GetString( "Skin", "Directory", "Default" );
    		strCurrentSkin += "\\default.ini";

    		CIni m_SkinFile( strCurrentSkin );
				
				m_nColorR_1 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_SELECTION_R", 255 );
    		m_nColorG_1 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_SELECTION_G", 173 );
    		m_nColorB_1 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_SELECTION_B", 27 );
				
				m_nColorR_2 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_VERTICAL_BAR_R", 0 );
    		m_nColorG_2 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_VERTICAL_BAR_G", 0 );
    		m_nColorB_2 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_VERTICAL_BAR_B", 0 );
				
				m_nColorR_3 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_BORDER_R", 0 );
    		m_nColorG_3 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_BORDER_G", 0 );
    		m_nColorB_3 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_BORDER_B", 0 );
				
				m_nColorR_4 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_TEXT_R", 0 );
    		m_nColorG_4 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_TEXT_G", 0 );
    		m_nColorB_4 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_TEXT_B", 0 );
    		
    		m_nColorR_5 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_TEXT_BACK_R", 255 );
    		m_nColorG_5 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_TEXT_BACK_G", 255 );
    		m_nColorB_5 = m_SkinFile.GetInt( "Color", "COLOR_TRAY_TEXT_BACK_B", 255 );
				
				m_bDrawShadow = FALSE;


        /*
				// selection
        XPColors.SetXPColor( CXPColors::XPC_INNER_SELECTION, RGB(m_nColorR_1,m_nColorG_1,m_nColorB_1) );
        XPColors.SetXPColor( CXPColors::XPC_OUTER_SELECTION, RGB(m_nColorR_1,m_nColorG_1,m_nColorB_1) );
        
        // vertical bar
				XPColors.SetXPColor( CXPColors::XPC_IMAGE_BACKGROUND, RGB(m_nColorR_2,m_nColorG_2,m_nColorB_2) );        
				
				// border
				XPColors.SetXPColor( CXPColors::XPC_IMAGE_DISABLED, RGB(m_nColorR_3,m_nColorG_3,m_nColorB_3) );        
				XPColors.SetXPColor( CXPColors::XPC_SEPARATOR, RGB(m_nColorR_3,m_nColorG_3,m_nColorB_3) );
				
        // text
				XPColors.SetXPColor( CXPColors::XPC_TEXT, RGB(m_nColorR_4,m_nColorG_4,m_nColorB_4) );

				// text back
        XPColors.SetXPColor( CXPColors::XPC_TEXT_BACKGROUND, RGB(m_nColorR_5,m_nColorG_5,m_nColorB_5) );
        XPColors.SetXPColor( CXPColors::XPC_INNER_CHECKED_SELECTED, RGB(m_nColorR_5,m_nColorG_5,m_nColorB_5) );        
        XPColors.SetXPColor( CXPColors::XPC_INNER_CHECKED, RGB(m_nColorR_5,m_nColorG_5,m_nColorB_5) );        
        XPColors.SetXPColor( CXPColors::XPC_OUTER_CHECKED, RGB(m_nColorR_5,m_nColorG_5,m_nColorB_5) );        
        XPColors.SetXPColor( CXPColors::XPC_TEXT_DISABLED, RGB(206,206,206) );
       */


}


// Render radioitem bullet.
void CSkinXPMenu::RenderRadioBullet( CDC *pDC, CRect& rcRect, COLORREF crColor, DWORD dwItemState )
{
    // Snapshot...
    int sDC = pDC->SaveDC();

    // Make ellipse rectangle.
    CRect rc = rcRect;
    rc.Right() = rc.Left() + 12;
    rc.Bottom() = rc.Top() + 12;
    rc.Offset( rcRect.Width() / 2 - 6, rcRect.Height() / 2 - 6 );

    // Create GDI objects for unchecked radio-button.
    CPen p( PS_SOLID, 0, RGB(m_nColorR_3,m_nColorG_3,m_nColorB_3));
    CBrush b( RGB(m_nColorR_5,m_nColorG_5,m_nColorB_5));

    // Brace the code so that the CSelector objects
    // go out of scope before the device context
    // is restored.
    {
        // Select brush and pen.
        CSelector sb( pDC, b );
        CSelector sp( pDC, p );

        // Render first ellipse... This yields better
        // results than the Ellipse() method...
        pDC->RoundRect( rc.Left(), rc.Top(), rc.Right(), rc.Bottom(), 11, 11 );

        // Deflate rectangle by three pixels.
        rc.Deflate( 3, 3 );

        // Checked?
        if ( dwItemState & ODS_CHECKED )
        {
            // Destroy current GDI objects and create new
            // ones for the inner ellipse.
            b.Delete(); p.Delete();
            b.CreateSolidBrush( crColor );
            p.CreatePen( PS_SOLID, 1, crColor );

            // Select them in the DC.
            CSelector sb( pDC, b );
            CSelector sp( pDC, p );

            // Rendert the ellipse.
            pDC->RoundRect( rc.Left(), rc.Top(), rc.Right(), rc.Bottom(), rc.Width() - 1, rc.Width() - 1 );
        }
    }

    // Restore original content.
    pDC->RestoreDC( sDC );
}

// Render a menu item in Office XP style.
#define ISKEYDOWN( code ) ( BOOL )( ::GetAsyncKeyState( code ) & ( 1 << 15 ))
void CSkinXPMenu::RenderItem( CDC *pDC, LPDRAWITEMSTRUCT pdis, ItemData *pData )
{
    // Determine the image, checkbox and text parts of the menu.
    CRect  rcCaption( pdis->rcItem ), rcImage( pdis->rcItem ), rcCheck;
    rcImage.Right() = rcImage.Left() + m_cxBitmap + 8;
    rcCaption.Left() += m_cxBitmap + 8;
    rcCheck = rcImage;
    rcCheck.Deflate( 1, 1 );
    rcCheck.Right()--;

    // A toplevel item?
    if ( pData->m_bToplevel )
    {
        // Selected or hot?
        if ( pdis->itemState & ODS_SELECTED || pdis->itemState & ODS_HOTLIGHT )
        {
            // Select appropiate colors.
            COLORREF crFg, crBg;
            if ( pdis->itemState & ODS_HOTLIGHT || ! IsDropped())
            {
                crFg = RGB(m_nColorR_1,m_nColorG_1,m_nColorB_1);
                crBg = RGB(m_nColorR_1,m_nColorG_1,m_nColorB_1);
            }
            else
            {
                crFg = RGB(m_nColorR_3,m_nColorG_3,m_nColorB_3);
                crBg = RGB(m_nColorR_2,m_nColorG_2,m_nColorB_2);
            }
            // Render the background.
            pDC->OutlinedRectangle( &pdis->rcItem, crFg, crBg );
        }
        else
            // Simply clear background.
            pDC->FillRect( &pdis->rcItem, ( HBRUSH )( COLOR_BTNFACE + 1 ));

        // Adjust the caption rectangle.
        rcCaption = pdis->rcItem;
        rcCaption.Offset( 6, 0 );
    }
    else
    {
        // Is the item selected?
        if (( pdis->itemState & ODS_SELECTED ) && pData->m_bSeparator == FALSE )
        {
            // Determine background color.
            COLORREF crBkgnd;

            // Is the item disabled or not?
            if ( ! ( pdis->itemState & ODS_DISABLED ))
                crBkgnd = RGB(m_nColorR_1,m_nColorG_1,m_nColorB_1);
            else
            {
                // See if either the up or the down arrow key is pressed.
                // If so the item is selected using one of these keys. In
                // That case we render the item differently.
                // 
                // Sorry about the goto...
                if ( ! ISKEYDOWN( VK_UP ) && ! ISKEYDOWN( VK_DOWN ) && ! ISKEYDOWN( VK_LEFT ) && ! ISKEYDOWN( VK_RIGHT )) goto normal;
                crBkgnd = RGB(m_nColorR_5,m_nColorG_5,m_nColorB_5);
            }
            // Render the selection rectangle.
            pDC->OutlinedRectangle( &pdis->rcItem, RGB(m_nColorR_1,m_nColorG_1,m_nColorB_1), crBkgnd );
        }
        else
        {
normal:
            // Render the image background.
            CBrush brush( RGB(m_nColorR_2,m_nColorG_2,m_nColorB_2) );
            pDC->FillRect( rcImage, &brush );

            // render the text background.
            brush.Delete(); 
            brush.CreateSolidBrush( RGB(m_nColorR_5,m_nColorG_5,m_nColorB_5) );
            pDC->FillRect( rcCaption, &brush );
        }

        // Is the item checked?
        if ( pdis->itemState & ODS_CHECKED )
        {
            // Disabled?
            COLORREF crBk, crFg;
            if ( ! ( pdis->itemState & ODS_DISABLED ))
            {
								// Select colors to use.
                crBk = pdis->itemState & ODS_SELECTED ? RGB(m_nColorR_5,m_nColorG_5,m_nColorB_5) : RGB(m_nColorR_5,m_nColorG_5,m_nColorB_5);
                crFg = RGB(m_nColorR_5,m_nColorG_5,m_nColorB_5);
            }
            else
            {
                // Select colors to use.
                crBk = RGB(m_nColorR_2,m_nColorG_2,m_nColorB_2);
                crFg = RGB(m_nColorR_3,m_nColorG_3,m_nColorB_3);
            }
            // Render checkbox image.
            pDC->OutlinedRectangle( rcCheck, crFg, crBk );

            // Does this item have a bitmap?
            if ( pData->m_iBitmap == -1 )
            {
                // Get the item type and checkmark information.
                CMenuItemInfo    mi;
                mi.fMask = MIIM_CHECKMARKS | MIIM_TYPE;
                if ( GetItemInfo( pdis->itemID, &mi ))
                {
                    // Radiobutton?
                    if ( mi.fType & MFT_RADIOCHECK )
                        // Render the radiobutton.
                        RenderRadioBullet( pDC, 
                                    rcCheck, 
                                    XPColors.GetXPColor( pdis->itemState & ODS_DISABLED ? CXPColors::XPC_IMAGE_DISABLED : CXPColors::XPC_TEXT ),
                                    pdis->itemState );
                    else
                        // Render the checkmark or checkmark bitmap.
                        RenderCheckmark( pDC, 
                                    rcCheck, 
                                    XPColors.GetXPColor( pdis->itemState & ODS_DISABLED ? CXPColors::XPC_IMAGE_DISABLED : CXPColors::XPC_TEXT ),
                                    XPColors.GetXPColor( CXPColors::XPC_TEXT ),
                                    pdis->itemState & ~ODS_DISABLED, 
                                    &mi );
                }
            }
        }
        // If we do not have a bitmap and we are
        // not a seperator we check to see if we
        // are a Radio-check item.
        else if ( pData->m_iBitmap == -1 && pData->m_bSeparator == FALSE )
        {
            // Radio item?
            CMenuItemInfo    mi;
            mi.fMask = MIIM_CHECKMARKS | MIIM_TYPE;
            if ( GetItemInfo( pdis->itemID, &mi ) && mi.fType & MFT_RADIOCHECK )
            {
                // Render the radiobutton.
                RenderRadioBullet( pDC, 
                            rcCheck, 
                            XPColors.GetXPColor( pdis->itemState & ODS_DISABLED ? CXPColors::XPC_IMAGE_DISABLED : CXPColors::XPC_TEXT ),
                            pdis->itemState );
            }
        }

        // Item data present?
        if ( pData )
        {
            // Separator?
            if ( pData->m_bSeparator == TRUE )
            {
                // Create and select pen to render the separator.
                CPen pen( PS_SOLID, 1, RGB(m_nColorR_3,m_nColorG_3,m_nColorB_3));
                CSelector s( pDC, pen );

                // Render the separator.
                rcCaption.Top() += rcCaption.Height() / 2;
                rcCaption.Left() += 8;
                pDC->MoveTo( rcCaption.TopLeft());
                pDC->LineTo( rcCaption.Right(), rcCaption.Top());
            }
            else
            {
                // Does the item have a bitmap assigned to it?
                if ( pData->m_iBitmap >= 0 && reinterpret_cast<CSkinXPMenu *>( pData->m_pOwner )->m_hImageList )
                {
                    // Adjust image position.
                    rcImage.Offset( -1, 0 );

                    // Determine image rendering flags.
                    DWORD dwFlags = 0;

                    if ( m_bDrawIconShadows && pdis->itemState & ODS_SELECTED && ( ! ( pdis->itemState & ODS_DISABLED )) && ( ! ( pdis->itemState & ODS_CHECKED )))
                        dwFlags |= CDrawTools::CDSF_HOT;
                    if ( pdis->itemState & ODS_DISABLED )
                        dwFlags |= CDrawTools::CDSF_DISABLED;

                    // Render image...
                    CDrawTools::RenderXPBitmap( *pDC, reinterpret_cast<CSkinXPMenu *>( pData->m_pOwner )->m_hImageList, pData->m_iBitmap, rcImage, dwFlags | CDrawTools::CDSF_TRANSPARENT );
                    
                    // Restore image rectangle position.
                    rcImage.Offset( 1, 0 );
                }
            }
        }
    }

    if ( pData )
    {
        // Any text?
        if ( pData->m_strItemName )
        {
            // Setup text color and draw mode.
            pDC->SetTextColor( pdis->itemState & ODS_INACTIVE ? 
						::GetSysColor( COLOR_GRAYTEXT ) : 
						( pdis->itemState & ODS_DISABLED ? RGB(206,206,206) 
						: RGB(m_nColorR_4,m_nColorG_4,m_nColorB_4)
            //XPColors.GetXPColor(CXPColors::XPC_TEXT )
              ));

						                       
						pDC->SetBkMode( TRANSPARENT );

            // Adjust the rectangle.
            if ( ! pData->m_bToplevel )
            {
                rcCaption.Left() += 8;
                rcCaption.Right() -= 6;
            }

            // Split caption in a left an right part.
            CString Left, Right;
            SplitCaption( pData->m_strItemName, Left, Right );
            
            
            // Set font
            LOGFONT lf = { 0 };
            memset( &lf, 0, sizeof(LOGFONT) );
            lf.lfHeight = 15;
            lf.lfCharSet = DEFAULT_CHARSET;
            lf.lfQuality = 5; // CLEARTYPE_QUALITY
            strncpy( lf.lfFaceName, "Arial", sizeof(lf.lfFaceName)-1 );

            HFONT hFont = ::CreateFontIndirect( &lf );
            if ( !hFont )
               hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);

            CFont font ( hFont );
            
            CSelector sel( pDC, font );


            // Render the parts.
            if ( Left.GetStringLength())  CDrawTools::RenderText( *pDC, Left,  rcCaption, CDrawTools::CDSF_LEFTALIGN | ( pdis->itemState & ODS_NOACCEL ? CDrawTools::CDSF_HIDEACCEL : 0 ));
            if ( Right.GetStringLength()) CDrawTools::RenderText( *pDC, Right, rcCaption, CDrawTools::CDSF_RIGHTALIGN );
        }
    }
}

// Reflected WM_MEASUREITEM message handler.
LRESULT CSkinXPMenu::OnReflectedMeasureItem( LPMEASUREITEMSTRUCT pmis, BOOL &bNotifyParent )
{
    // Menu?
    if ( pmis->CtlType != ODT_MENU )
        return FALSE;

    // Old style?
    if ( m_bDrawOldStyle ) 
        return CBitmapMenu::OnReflectedMeasureItem( pmis, bNotifyParent );

    // Are we a separator? If so we set the values
    // ourselves.
    ItemData *pData = ( ItemData * )pmis->itemData;
    if ( pData == NULL ) return FALSE;
    if ( pData->m_bSeparator == TRUE )
    {
        bNotifyParent = FALSE;
        pmis->itemHeight = 3;
        pmis->itemWidth = 4;
        return TRUE;
    }

    // We let the base class do the computation.
    if ( CBitmapMenu::OnReflectedMeasureItem( pmis, bNotifyParent ) == TRUE )
    {
        // Adjust the base class results to suit
        // our needs.
        if ( ! pData->m_bToplevel )
        {
            pmis->itemWidth += 20;
            pmis->itemHeight += 2;
        }
        return TRUE;
    }
    return FALSE;
}

// Reflected WM_DRAWITEM message handler.
LRESULT CSkinXPMenu::OnReflectedDrawItem( LPDRAWITEMSTRUCT pdis, BOOL& bNotifyParent )
{
    // Old style?
    if ( m_bDrawOldStyle )
        // Let the baseclass take care of rendering.
        return CBitmapMenu::OnReflectedDrawItem( pdis, bNotifyParent );

    // Menu?
    if ( pdis->CtlType != ODT_MENU )
        return FALSE;

    // No need to bother the parent.
    bNotifyParent = FALSE;

    // Get the item data.
    ItemData *pData = ( ItemData * )pdis->itemData;

    // Wrap the DC.
    CDC    cDC( pdis->hDC );
    int    sDC = cDC.SaveDC();

    // Render the item.
    RenderItem( &cDC, pdis, pData );

    // Restore DC changes.
    cDC.RestoreDC( sDC );
    return TRUE;
}

// Refresh the parent rectangle.
void CSkinXPMenu::RefreshParentRectangle( CWindow *pWindow )
{
    // Do we have a parent rectangle?
    CRect rc( m_LastParent );
    if ( ! rc.IsEmpty())
    {
        // Add 4 pixels for the shadows.
        rc.Right() += 4;
        rc.Bottom() += 4;

        // Convert to client coordinates.
        pWindow->ScreenToClient( rc );

        // Refresh the rectangle.
        pWindow->InvalidateRect( rc );
        pWindow->UpdateWindow();
    }

}

// Popup menu closed.
void CSkinXPMenu::OnReflectedUnInitMenuPopup( CWindow *pWindow, HMENU hPopup, LPARAM lParam )
{
    RefreshParentRectangle( pWindow );
    CBitmapMenu::OnReflectedUnInitMenuPopup( pWindow, hPopup, lParam );
}

// Menu loop exited.
void CSkinXPMenu::OnReflectedExitMenuLoop( CWindow *pWindow, BOOL bShortcut )
{
    // Obtain menu-bar information.
    MENUBARINFO mbi;
    mbi.cbSize = sizeof( mbi );
    if ( ::GetMenuBarInfo(( HWND )pWindow->GetMenu(), OBJID_MENU, 0, &mbi ))
    {
        // Refresh the rectangle including the space
        // the shadow took up.
        mbi.rcBar.bottom += 4;
        pWindow->InvalidateRect( &mbi.rcBar );
    }
    else
        // Entire window...
        pWindow->Invalidate();

    // Update.
    pWindow->UpdateWindow();
    CBitmapMenu::OnReflectedExitMenuLoop( pWindow, bShortcut );
}

// Do we render frames?
BOOL CSkinXPMenu::DoFrameRendering()
{ 
    // Old style, let the baseclass decide.
    if ( m_bDrawOldStyle ) 
        return CBitmapMenu::DoFrameRendering();

    // Yes, we do it ourselves.
    return TRUE; 
}

// Measure the frame.
void CSkinXPMenu::OnMeasureFrame( LPRECT pRect )
{ 
    // Old style, let the baseclass decide.
    if ( m_bDrawOldStyle )
    {
        CBitmapMenu::OnMeasureFrame( pRect );
        return;
    }

    // Setup frame size in pixels.
    pRect->left = pRect->top = 2;
    pRect->right = pRect->bottom = m_bDrawShadow ? ( CGetApp()->IsShadowEnabled() ? 2 : 6 ) : 2;
}

// Adjust popup menu position size.
void CSkinXPMenu::OnChangeWindowPos( LPWINDOWPOS pWindowPos )
{
    // Old style, let the baseclass decide.
    if ( m_bDrawOldStyle )
    {
        CBitmapMenu::OnChangeWindowPos( pWindowPos );
        return;
    }

    // If the menu opens below the parent we will put it one
    // pixel up. If it opens above we put it 3 pixels down. This
    // will make it intersect with the parent item.
    if ( ! ( pWindowPos->flags & SWP_NOMOVE ))
    {
        if ( m_LastParent.Bottom() <= pWindowPos->y ) pWindowPos->y--;
        else                          pWindowPos->y += 3;

        // Windows 2000 has the anoying habbit to open the menu right
        // of the parent item the first time it has to open above
        // the parent when we use custom frames. We adjust it here.
        if ( pWindowPos->x == m_LastParent.Right()) pWindowPos->x = m_LastParent.Left();
    }
}

// Called just before the OnDrawFrame() overidable is called.
void CSkinXPMenu::PreDrawFrame( LPCRECT pRect, LPCRECT pRectScr )
{
    // Old style?
    if ( m_bDrawOldStyle )
    {
        // Let the baseclass take care of rendering.
        CBitmapMenu::PreDrawFrame( pRect, pRectScr );
        return;
    }

    // Do we render the shadow?
    CRect rc;
    if ( m_LastParent.IsEmpty() == FALSE && m_bDrawShadow )
    {
        // Get the desktop DC.
        CWindowDC wdc( NULL );
        if ( wdc.IsValid())
        {
            // Copy the parent rectangle and adjust the width
            // for the shadow.
            rc = m_LastParent;
            rc.Right() += 4;
            rc.Bottom() += 4;

            // Render the shadow at the parent rectangle.
            CDrawTools::DrawShadow( wdc, rc );
        }
    }
}

// Render the menu frame.
void CSkinXPMenu::OnDrawFrame( HDC hDC, LPCRECT pRect, LPCRECT pRectScr )
{
    // Old style, let the baseclass decide.
    if ( m_bDrawOldStyle )
    {
        CBitmapMenu::OnDrawFrame( hDC, pRect, pRectScr );
        return;
    }

    // Wrap the input DC.
    CDC *pDC = CDC::FromHandle( hDC );
    if ( pDC == NULL ) return;

    // Copy the input rectangle.
    CRect rc( *pRect );

    // Are shadows enabled? If so we only render the frame.
    // If not we have room to render the shadow ourselves.
    if ( ! CGetApp()->IsShadowEnabled() && m_bDrawShadow )
    {
        // Adjust for the shadow pixels.
        rc.Right()  -= 4;
        rc.Bottom() -= 4;
    }

    // Create brush and render the outer frame.
    CBrush brush( RGB(m_nColorR_3,m_nColorG_3,m_nColorB_3));
    pDC->FrameRect( rc, &brush ); 

    // Do the same for the inner frame.
    brush.Delete();
    rc.Deflate( 1, 1 );
    brush.CreateSolidBrush( RGB(m_nColorR_4,m_nColorG_4,m_nColorB_4));
    pDC->FrameRect( rc, &brush );

    // Do we render the shadow ourselves?
    if ( ! CGetApp()->IsShadowEnabled() && m_bDrawShadow )
    {
        // Do we have a parent rectangle?
        if ( m_LastParent.IsEmpty() == FALSE )
        {
            // If the right-sides match we adjust the shadow rectangle to
            // be a union of both rectangle.
            if ( m_LastParent.Right() == pRectScr->right - 4 )
            {
                CRect rc;
                rc.Union( m_LastParent, *pRectScr );
                rc.Offset( -pRectScr->left, -pRectScr->top );
                CDrawTools::DrawShadow( hDC, rc );
            }
            else
                CDrawTools::DrawShadow( hDC, pRect );
        }
        else
            CDrawTools::DrawShadow( hDC, pRect );
    }

    // Valid parent?
    if ( m_LastParent.IsEmpty() == FALSE )
    {
        // Create an intersection of the menu rectangle and the
        // parent-item rectangle.
        CRect RealRect( *pRectScr );

        // Do we have a shadow?
        if ( ! CGetApp()->IsShadowEnabled() && m_bDrawShadow )
            RealRect.Right() -= 4;

        // Clear the intersection.
        if ( rc.Intersect( RealRect, m_LastParent ))
        {
            // Create a rectangle relative to the menu top-left.
            rc.Offset( -pRectScr->left, -pRectScr->top );

            // Adjust to fit.
            if ( rc.Width() > rc.Height()) rc.Deflate( 1, 0 ); else rc.Deflate( 0, 1 );

            // Create a brush to erase the rectangle, which actually
            // is a line instead of a true rectangle.
            brush.Delete();
            brush.CreateSolidBrush( RGB(m_nColorR_2,m_nColorG_2,m_nColorB_2) );

            // Render.
            pDC->FillRect( rc, brush );
        }
    }
}

CString CSkinXPMenu::GetModulePath()
{
    TCHAR lpFilename[MAX_PATH]={0};
    ::GetModuleFileName( GetModuleHandle(NULL), lpFilename, sizeof(lpFilename) );

    CString sTempname(lpFilename);
    CString sProgPath = "";
    sProgPath = sTempname.Left( sTempname.ReverseFind( '\\') ); //'

    return sProgPath;
}


