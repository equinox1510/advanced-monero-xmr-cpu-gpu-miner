
#include "classes/include/all.h"
#include <windows.h>

bool CSystemTimeToLocalTime( const SYSTEMTIME *pUtcTime, SYSTEMTIME *lpdate );



