#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_MAIN                                101
#define IDI_MAIN                                102
#define IDI_MEMORY                              104
#define IDI_KEY                                 105
#define IDI_FILE                                106
#define IDI_INFO                                107
#define IDD_ABOUT                               108
#define IDB_BITMAP                              109
#define IDR_MENU_POPUP                          110
#define IDD_TEST                                111
#define IDB_BITMAP1                              112
#define IDC_TEXT                                1001
#define IDC_TEXT2                               1003
#define IDC_TEXT4                               1005
#define IDC_TEXT1                               1008
#define IDC_SETALERT                            1009
#define IDC_LOGO                                40016
#define ID_POPUP_CREATEEDIT                     40017
#define ID_POPUP_LOADATSTARTUP                  40018
#define ID_POPUP_ABOUT                          40019
#define ID_POPUP_QUIT                           40021
#define IDC_URL                                 40022
#define IDC_USERNAME                            40023
#define IDC_PASSWORD                            40024
#define IDC_TLS                                 40025
