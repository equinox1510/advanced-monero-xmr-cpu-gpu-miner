
#include "classes/include/all.h"


#define  MONEROMINER_IPC_QUEUE_USER			   _T("\\\\.\\pipe\\MONEROMINER_IPC_QUEUE_USER")




#define MAX_VALUE_SIZE 307200

// IPC queue structure
struct ipc_queue
{
    int                     id;
    int                     type;    

		int                     result;    

    int											nid;
    char                    name[1024];
    char                    method[1024];
    int											action;

    char                    path[4096];
    char                    path_parent[4096];
    char                    path_location[4096];

};


void WaitForOperationToComplete( UINT iTimeToComplete );

void SendIPCMessageAndReceive( CString sPipeName, void* Data, DWORD DataLen, void* DataOut, DWORD DataLenOut );

void SendIPCMessage( CString sPipeName, void* Data, DWORD DataLen );



BOOL IPCWakeUpIfRunning();



