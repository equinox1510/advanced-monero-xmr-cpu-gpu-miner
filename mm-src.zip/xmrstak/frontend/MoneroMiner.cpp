#include <ws2spi.h>
#include <sporder.h>
#include <winsock2.h>
#include <ws2spi.h>
#include <objbase.h>
#include <rpc.h>
#include <rpcdce.h>
#include <sporder.h>
#include <winnt.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#include "xmrstak/misc/executor.hpp"
#include "xmrstak/backend/miner_work.hpp"
#include "xmrstak/backend/globalStates.hpp"
#include "xmrstak/backend/backendConnector.hpp"
#include "xmrstak/jconf.hpp"
#include "xmrstak/misc/console.hpp"
#include "xmrstak/donate-level.hpp"
#include "xmrstak/params.hpp"
#include "xmrstak/misc/configEditor.hpp"
#include "xmrstak/version.hpp"
#include "xmrstak/misc/utility.hpp"

#ifndef CONF_NO_HTTPD
#	include "xmrstak/http/httpd.hpp"
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <time.h>
#include <iostream>

#ifndef CONF_NO_TLS
#include <openssl/ssl.h>
#include <openssl/err.h>
#endif

#ifdef _WIN32
#	define strcasecmp _stricmp
#	include <windows.h>
#endif // _WIN32

#include "classes/include/all.h"
#include "CTaskManager.h"
#include "CTimeZone.h"
#include "CSystemTray.h"
#include "CMd5.h"
#include "CIni.h"
#include "CIPC.h"
#include "CWSocket.h"


#include "resource.h"
#include "resrc1.h"
 
#define MAX_KEY_LENGTH 255
#define MAX_VALUE_NAME 16383
#define MAX_VALUE_VALUE 4096

#define THREAD_STOPPED  WM_USER + 4620 // Thread messages posted to

const UINT ID_CHECK_TIMER = 1;
CCriticalSection m_CriticalStat;
//


class AboutDialog : public CDialog
{
    _NO_COPY( AboutDialog );
    
public:

    AboutDialog()
    {
       m_hLogoBmp = NULL;


       TCHAR dataPath[MAX_PATH]={0};
       ::SHGetSpecialFolderPath( NULL, dataPath, CSIDL_APPDATA, FALSE );

       // Load settings file
       CString strSettings = dataPath;
       strSettings += "\\MoneroMiner\\settings.ini";

       m_SettingsFile.SetPathName( strSettings );
    }

    CString GetModulePath()
    {
        TCHAR lpFilename[MAX_PATH]={0};
        ::GetModuleFileName( GetModuleHandle(NULL), lpFilename, sizeof(lpFilename) );

        CString sTempname(lpFilename);
        CString sProgPath;
        sProgPath = sTempname.Left( sTempname.ReverseFind( '\\') ); //'

        return sProgPath;
    }

    virtual ~AboutDialog()
    {
        if (m_hLogoBmp)
            ::DeleteObject(m_hLogoBmp);
    }

protected:


    virtual BOOL OnOK()
    {
        return CDialog::OnOK();
    }


    virtual LRESULT OnInitDialog( PROPSHEETPAGE *p )
    {
        SetWindowText( "About" );
        
        
        m_Logo.Attach( GetDlgItemHandle( IDC_LOGO ));

        m_Ok.Attach( GetDlgItemHandle( IDOK ));

        m_Text.Attach( GetDlgItemHandle( IDC_TEXT ));
        

        return CDialog::OnInitDialog( p );
    }

    
    void ReplaceString( CString newstrin, CString oldstr, CString& retstr, BOOL bContinuous )
    {
        LPSTR newstr = newstrin;
        CString oldone_lower( oldstr );

        if ( bContinuous )
        {
            int pos = 0;
            while ( (pos = retstr.Find(oldone_lower,pos))!=-1 )
            {
                retstr.Delete( pos, lstrlen(oldstr) );
                retstr.Insert( pos, newstr );
            }
        }
        else
        {
            int pos = 0;
            if ( (pos = retstr.Find(oldone_lower,pos))!=-1 )
            {
                retstr.Delete( pos, lstrlen(oldstr) );
                retstr.Insert( pos, newstr );
            }
        }
    }

    LRESULT WindowProc( UINT uMsg, WPARAM wParam, LPARAM lParam )
    {
        /*switch ( uMsg )
        {
            // window dragging
            case WM_LBUTTONDOWN:
            {
                SendMessage( WM_NCLBUTTONDOWN, HTCAPTION, NULL );
                break;
            } 

        }   */
        return CDialog::WindowProc( uMsg, wParam, lParam );
    }


    CButton       m_Ok;

    CStatic       m_Text;
    CStatic       m_Logo;


    CIni 					m_SettingsFile;
    
    CStatic       m_Icon;

    HBITMAP       m_hLogoBmp;

};

class StatDialog : public CDialog
{
    _NO_COPY( StatDialog );
    
public:

    StatDialog()
    {
    }
	
    void AppendStat( CString parts )
    {
		/*ReplaceString( "\r\n", "\n", text, TRUE );
		
		int nLength = m_Text.GetWindowTextLength();
		m_Text.SetSel(nLength, nLength);
		m_Text.ReplaceSel( "\r\n"  + text);
		*/
		
		int find = parts.Find( _TCHAR( '\n' ) );  //'
        while( find != -1 )
        {
            m_Text.AddString( parts.Left( find ) );
			
            parts = parts.Right( parts.GetStringLength( ) - ( find + 1 ) );
            if ( parts.IsEmpty() )
                find = -1;
            else
                find = parts.Find( _TCHAR( '\n' ) );                         //'
        }

        if( parts.GetStringLength( ) )
            m_Text.AddString( parts );
		
		
		//m_Text.AddString( text );
	}	
	

    CString GetModulePath()
    {
        TCHAR lpFilename[MAX_PATH]={0};
        ::GetModuleFileName( GetModuleHandle(NULL), lpFilename, sizeof(lpFilename) );

        CString sTempname(lpFilename);
        CString sProgPath;
        sProgPath = sTempname.Left( sTempname.ReverseFind( '\\') ); //'

        return sProgPath;
    }
	
	void ReplaceString( CString newstrin, CString oldstr, CString& retstr,
										BOOL bContinuous )
	{
		LPSTR newstr = newstrin;
		CString oldone_lower( oldstr );

		if ( bContinuous )
		{
			int pos = 0;
			while ( (pos = retstr.Find(oldone_lower,pos))!=-1 )
			{
				retstr.Delete( pos, lstrlen(oldstr) );
				retstr.Insert( pos, newstr );
				pos += lstrlen( newstr );
			}
		}
		else
		{
			int pos = 0;
			if ( (pos = retstr.Find(oldone_lower,pos))!=-1 )
			{
				retstr.Delete( pos, lstrlen(oldstr) );
				retstr.Insert( pos, newstr );
			}
		}
	}	

    virtual ~StatDialog()
    {
    }

protected:


    virtual BOOL OnOK()
    {
        ShowWindow( SW_HIDE );
		
		return CDialog::OnOK();
    }


    virtual LRESULT OnInitDialog( PROPSHEETPAGE *p )
    {
        SetWindowText( "Statistics" );
        
        m_Text.Attach( GetDlgItemHandle( IDC_STAT_VIEW ));

        return CDialog::OnInitDialog( p );
    }
    
    CListBox       m_Text;
};

StatDialog *statWindow = NULL;

class MoneroMinerDialog : public CDialog
{
    _NO_COPY( MoneroMinerDialog );
public:
    MoneroMinerDialog();

    virtual ~MoneroMinerDialog();
	
	int StartMining();

	void Benchmark();

protected:

    // Convert the tabs in the string to spaces. Uses a tab-size of 8.
    static CString *ConvertForPrint( LPCTSTR pszSource );

    // Add a backslash to the string.
    static void AddBackslash( CString& str );

    void LogMessage( CString message );

    static void ReplaceString( CString newstrin, CString oldstr, CString& retstr,
                                    BOOL bContinuous = FALSE );
                                    
    CString RemoveHtmlData( CString sData );

    CString GetModulePath();
	
	CString GetDataPath();

    BOOL SetOptionInt( CString keyName, int value);

    BOOL GetOptionString( CString keyName, CString& value );

    BOOL GetOptionInt( CString keyName, int& value );

    BOOL SetOptionString( CString keyName, CString value );

    BOOL SetOptionStringLocation( CString keyName, CString value, CString location);

    BOOL GetOptionStringLocation( CString keyName, CString& value, CString location );

	  CString MoneroMinerDialog::rfc1738_encode( CString src );

	  unsigned int FindSize( unsigned int n, CString& source );


    int GetUrlData( CString sUrl, CString& sData, CString szFile = "", int nPort = 80 );


    // WM_INITDIALOG message handler...
    virtual LRESULT OnInitDialog( PROPSHEETPAGE *p );

    // WM_CLOSE handler.
    virtual LRESULT OnClose();

    // This is not allowed to end the dialog.
    virtual BOOL OnOK() { return FALSE; }

    // Escape key pressed.
    virtual BOOL OnCancel();

    // Window procedure override.
    virtual LRESULT WindowProc( UINT uMsg, WPARAM wParam, LPARAM lParam );

    // WM_COMMAND message handler.
    virtual LRESULT OnCommand( UINT nNotifyCode, UINT nCtrlID, HWND hWndCtrl );

    virtual LRESULT OnNotify( LPNMHDR pNMHDR );

    virtual LRESULT OnSize( UINT nSizeType, int nWidth, int nHeight )
    {
       return CDialog::OnSize( nSizeType, nWidth, nHeight );
    }
    
    static UINT WINAPI IPCQueueNotifier( LPVOID param );
    
    void StopIPCQueueNotifier();
    
    void StartIPCQueueNotifier();


    // Control objects.
    CStatic                         m_Text1;
    CStatic                         m_Text2;
    CStatic                         m_Text3;
    CStatic                         m_Text4;

    CEdit                           m_Url;
    CEdit                           m_Username;
    CEdit                           m_Password;
    CComboBox                       m_TLS;
	
    CButton                         m_SetAlert;
    CButton                         m_CancelAlert;


    CWorkerThread               	  m_IPCQueueThread;
    BOOL												 	  m_bIPCQueueThread;
    BOOL														m_bIPCQueueThreadRun;

    BOOL                            m_bClosingApp;

    HICON                           m_hIcon;

    CFile                           logFile;
    CString                         logFileName;

    UINT_PTR                        m_nCheckTimer;
    BOOL                            m_bChecked;

    CSystemTray                     m_trayIcon;

    CIni                            m_SettingsFile;

};


CString MoneroMinerDialog::GetDataPath()
{
    TCHAR DataPath[MAX_PATH]={0};
    ::SHGetSpecialFolderPath( NULL, DataPath, CSIDL_COMMON_APPDATA, FALSE );
    CString sDataPath = "";
    sDataPath = DataPath;
    sDataPath += "\\MoneroMiner";

    return sDataPath;
}


void MoneroMinerDialog::ReplaceString( CString newstrin, CString oldstr, CString& retstr,
                                    BOOL bContinuous )
{
    LPSTR newstr = newstrin;
    CString oldone_lower( oldstr );

    if ( bContinuous )
    {
        int pos = 0;
        while ( (pos = retstr.Find(oldone_lower,pos))!=-1 )
        {
            retstr.Delete( pos, lstrlen(oldstr) );
            retstr.Insert( pos, newstr );
            pos += lstrlen( newstr );
        }
    }
    else
    {
        int pos = 0;
        if ( (pos = retstr.Find(oldone_lower,pos))!=-1 )
        {
            retstr.Delete( pos, lstrlen(oldstr) );
            retstr.Insert( pos, newstr );
        }
    }
}

void MoneroMinerDialog::LogMessage( CString message )
{
    try
    {
       DWORD dwSize = message.GetStringLength();

       if ( dwSize > 0 )
       {
           logFile.Write( (LPSTR)message, dwSize );
           logFile.Flush();
       }
    }
    catch( CFileException/*& e*/)
    {
//       MessageBox( e.m_sDescription , _T( "Information" ), MB_ICONERROR | MB_OK );
    }
    catch( CMemoryException& )
    {
//       MessageBox( _T( "Out of memory" ), _T( "Information" ), MB_ICONERROR | MB_OK );
    }
}

CString MoneroMinerDialog::GetModulePath()
{
    char lpFilename[MAX_PATH];
    ::GetModuleFileName( GetModuleHandle(NULL), lpFilename, sizeof(lpFilename) );

    CString sTempname(lpFilename);
    CString m_ProgPath;
    m_ProgPath = sTempname.Left( sTempname.ReverseFind( '\\') ); //'

    return m_ProgPath;
}

BOOL MoneroMinerDialog::SetOptionInt( CString keyName, int value)
{
    CRegKey key;

    if ( key.CreateKey( HKEY_CURRENT_USER, _T( "Software\\MoneroMiner" )) == ERROR_SUCCESS )
    {
        if ( key.SetValue( (DWORD)value, keyName ) != ERROR_SUCCESS )
                    return FALSE;
        else return TRUE;
    }
    return FALSE;
}

BOOL MoneroMinerDialog::GetOptionString( CString keyName, CString& value )
{
    CRegKey key;
    TCHAR szPath[ MAX_PATH + 1 ];

    if ( key.OpenKey( HKEY_CURRENT_USER, _T( "Software\\MoneroMiner" )) == ERROR_SUCCESS )
    {
        DWORD dwSize = MAX_PATH;
        if ( key.QueryValue( keyName, ( LPTSTR )&szPath, &dwSize ) == ERROR_SUCCESS )
        {
            value = szPath;
            return TRUE;
        }
        else return FALSE;
        
        return TRUE;
    }
    return FALSE;
}

BOOL MoneroMinerDialog::GetOptionInt( CString keyName, int& value )
{
    CRegKey key;

    if ( key.OpenKey( HKEY_CURRENT_USER, _T( "Software\\MoneroMiner" )) == ERROR_SUCCESS )
    {
        DWORD dwSize = 0;
        if ( key.QueryValue( keyName, dwSize ) == ERROR_SUCCESS )
        {
            value = (int)dwSize;
            return TRUE;
        }
        else return FALSE;

        return TRUE;
    }
    return FALSE;
}


BOOL MoneroMinerDialog::SetOptionString( CString keyName, CString value )
{
    CRegKey key;

    if ( key.CreateKey( HKEY_CURRENT_USER, _T( "Software\\MoneroMiner" )) == ERROR_SUCCESS )
    {
        if ( key.SetValue( value, keyName ) != ERROR_SUCCESS )
                    return FALSE;
        else return TRUE;
    }
    return FALSE;
}

BOOL MoneroMinerDialog::SetOptionStringLocation( CString keyName, CString value, CString location)
{
    CRegKey key;

    if ( key.CreateKey( HKEY_CURRENT_USER, _T( location )) == ERROR_SUCCESS )
    {
        if ( key.SetValue( value, keyName ) != ERROR_SUCCESS )
                    return FALSE;
        else return TRUE;
    }
    return FALSE;
}

BOOL MoneroMinerDialog::GetOptionStringLocation( CString keyName, CString& value, CString location )
{
    CRegKey key;
    TCHAR szPath[ MAX_PATH + 1 ];

    if ( key.OpenKey( HKEY_CURRENT_USER, _T( location )) == ERROR_SUCCESS )
    {
        DWORD dwSize = MAX_PATH;
        if ( key.QueryValue( keyName, ( LPTSTR )&szPath, &dwSize ) == ERROR_SUCCESS )
        {
            value = szPath;
            return TRUE;
        }
        else return FALSE;

        return TRUE;
    }
    return FALSE;
}

/*
* Encode string per RFC1738 URL encoding rules
*/
CString MoneroMinerDialog::rfc1738_encode( CString src )
{
    static    char hex[] = "0123456789ABCDEF";
    CString dst = "";

    for (int i = 0; i < src.GetStringLength(); i++)
    {
        if (isalnum( src[i] ))
        {
            dst += src[i];
        }
        else
        if (src[i] == ' ')
        {
            dst += '+';
        }
        else
        {
            unsigned char c = src[i];
            unsigned short asc = c;

            dst += '%';
            CString sHex = "";
            sHex.Format( "%02X", asc );
            dst += sHex;
        }
    }
    
    return dst;
}

unsigned int MoneroMinerDialog::FindSize( unsigned int n, CString& source )
{
    unsigned int end, crlf, semicolon, size;
    
    size = 0;


    crlf = source.Find("\r\n", n);
    if (crlf == -1)
        return -1;

    semicolon = source.Find(";", n);
    if (semicolon == -1)
        semicolon = crlf;

    if (semicolon < crlf)
        end = semicolon;
    else
        end = crlf;

    CString ss = "";
    ss = source.Mid( n, end - n );

    if ( !source.IsEmpty() )
    {
        size = (int)strtoul( (LPSTR)ss, 0, 16 );
    }

    return size;
}

                       
int MoneroMinerDialog::GetUrlData ( CString sUrl, CString& sData, 
                                 CString szFile/* = ""*/, int nPort/* = 80*/ )
{
    char    szQuery[512]={0};
    char    szBuffer[4096]={0};
    BOOL    szResult = TRUE;
    CString sHeader = "";

    CString sProxyHost = "";
    GetOptionString( "ProxyHost", sProxyHost );
    sProxyHost.Trim();
    
    int nProxyPort = 8080;
    GetOptionInt( "ProxyPort", nProxyPort );

    CString sProxyLogin = "";
    GetOptionString( "ProxyLogin", sProxyLogin );
    sProxyLogin.Trim();

    CString sProxyPassword = "";
    GetOptionString( "ProxyPassword", sProxyPassword );
    sProxyPassword.Trim();
    
    int nProxyType = 0;
    GetOptionInt( "ProxyType", nProxyType );

    CString szServer = "";
    CString szObject = "";

    int pos = 0;
    pos = sUrl.Find("//");
    if ( pos == -1 ) pos = 0;

    if ( (pos = sUrl.Find('/', pos+2)) != -1 )
    {
          szObject = sUrl.Mid( pos, sUrl.GetStringLength()-pos );

          szServer = sUrl;
          szServer.SetStringLength( pos );
          
          ReplaceString( "", "http://", szServer, FALSE );
          szServer.Trim();
    }
    
    
redir:
    szResult = TRUE;
    sHeader = "";
    

    _snprintf( szQuery, sizeof(szQuery)-1,
                      "GET %s HTTP/1.1\r\n"
                      "User-Agent: Mozilla/4.07 \r\n"
                      "Host: %s\r\n"
                      "Connection: Close\r\n"
                      "\r\n\r\n",
                      (LPSTR)szObject, (LPSTR)szServer );

    CWSocket* socket = 0;

    try
    {
        // Proxy set
        if ( !sProxyHost.IsEmpty() )
        {
						socket = new CWSocket();
						socket->Create();
						
						if ( nProxyType == 0 )
						{
						     CString sProxyResponse = "";
								 socket->ConnectViaHTTPProxy( (LPSTR)szServer, nPort, sProxyHost, nProxyPort, sProxyResponse, (LPSTR)sProxyLogin, (LPSTR)sProxyPassword, 15000, "Get" );
            }
            else if ( nProxyType == 1 )
            {
 						     socket->ConnectViaSocks5( (LPSTR)szServer, nPort, sProxyHost, nProxyPort, (LPSTR)sProxyLogin, (LPSTR)sProxyPassword, 15000 );
            }
        }
        else
        {
            socket = new CWSocket();
						socket->Create();
						socket->Connect( (LPSTR)szServer, nPort, 15000 );
        }

    }
    catch( CWSocketException* pEx )
    {
        //MessageBox( NULL, pEx->GetErrorMessage(), "TEST", MB_OK );
        //OutputDebugString( pEx->GetErrorMessage() );
        delete pEx;

        szResult = FALSE;
        return szResult;
    }


    // Send query
    int  iResult = socket->Send( szQuery, strlen(szQuery), 0 );

    // Quit on error
    if ( iResult <= 0 )
        return FALSE;
        

    try
    {
        CFile downloadFile;

        if ( !szFile.IsEmpty() )
        {
           // Delete file if exists
           ::SetFileAttributes( szFile, FILE_ATTRIBUTE_NORMAL );
           ::DeleteFile( szFile );

           downloadFile.Open( szFile, CFile::fileWrite | CFile::fileCreate | CFile::fileShareRead | CFile::fileShareWrite);
        }

        // Get HTTP header
        do
        {
            // Clear buffer before each iteration
            memset( szBuffer, 0, sizeof(szBuffer) );

            // Try to receive some data
            iResult = socket->Receive( szBuffer, 1, 0 );
            
            // Quit if no more data
            if ( iResult <= 0 )
                break;

            // Add this data to the result string
            sHeader += szBuffer;
        }
        while ( (sHeader.Find( "\r\n\r\n" ) == -1) );
        

        // Get body
        DWORD dwLength = 0;
        BOOL bChunked = FALSE;

        if ( !sHeader.IsEmpty() )
        {
           sHeader.UpperCase();

           int pos = 0;
           
           
           if ( sHeader.Find( "HTTP/1.0 303" ) != -1 )
           {
             if ( ( pos = sHeader.Find( "LOCATION:" )) != -1 )
             {
                int pos1 = 0;
                if ( ( pos1 = sHeader.Find( "\n", pos+1 )) != -1 )
                {
                     CString sLocNew = "";
                     sLocNew = sHeader.Mid( pos+16, pos1-pos-16 );
                     sLocNew.Trim();
                     sLocNew.LowerCase();

                     ReplaceString( "", "http://", sLocNew, FALSE );
       					 		 ReplaceString( "", szServer, sLocNew, FALSE );
       					 		 
       					 		 szObject = sLocNew;
       					 		 //OutputDebugString( szObject );
       					 		 goto redir;
                }
             }
           }

           pos = 0;
           if ( ( pos = sHeader.Find( "CONTENT-LENGTH:" )) != -1 )
           {
                int pos1 = 0;
                if ( ( pos1 = sHeader.Find( "\n", pos+1 )) != -1 )
                {
                     CString sLength = "";
                     sLength = sHeader.Mid( pos+16, pos1-pos-16 );
                     sLength.Trim();

                     if ( !sLength.IsEmpty() )
                     {
                        dwLength = atol( (LPSTR)sLength );
                     }
                }
            }
            
            if ( ( pos = sHeader.Find( "CHUNKED" )) != -1 )
            {
                  bChunked = TRUE;
            }

        }
        


        DWORD dWriteFileTotal = 0;
        
				sData = "";
				
        do
        {
            // Clear buffer before each iteration
            memset( szBuffer, 0, sizeof(szBuffer) );

            // Try to receive some data
            iResult = socket->Receive( szBuffer, 4095, 0 );
            

           // Quit if no more data
            if ( iResult <= 0 )
                break;


            BOOL bStopChunked = FALSE;

         		if ( bChunked )
         		{
                  CString sBuffer = "";
                  sBuffer += szBuffer;

                  unsigned int size = 0;
                  int pos = 0;
                  BOOL bNoStruct = TRUE;

                  while ( (size = FindSize(pos, sBuffer)) != -1 )
                  {
                      bNoStruct = FALSE;
                      
                      if ( size == 0 )
                      {
                          bStopChunked = TRUE;
                          break;
                      }
                      
                      pos = sBuffer.Find("\r\n", pos);
                      if ( pos == -1 )
                      {
                          bStopChunked = TRUE;
                          break;
                      }
                      
                      pos += 2;

                      if ( size > (unsigned int)(sBuffer.GetStringLength()-pos) )
                      {
                            size = (unsigned int)(sBuffer.GetStringLength()-pos);
                      }
                      
                      //
                      CString sChunk = "";
                      sChunk = sBuffer.Mid( pos, size );

                      if ( !sChunk.IsEmpty() )
                      {
                          sData += (LPSTR)sChunk;

                          if ( !szFile.IsEmpty() )
                              downloadFile.Write( (LPSTR)sChunk, sChunk.GetStringLength() );
                      }
                      //

                      pos += size + 2;
                  }

                  if ( bNoStruct )
                  {
                      sData += szBuffer;

                      if ( !szFile.IsEmpty() )
                          downloadFile.Write( szBuffer, iResult );
                  }
            }
            else
            {
                sData += szBuffer;

                if ( !szFile.IsEmpty() )
                    downloadFile.Write( szBuffer, iResult );
            }



            dWriteFileTotal += iResult;
            
            // We have already downloaded what we should
            if ( dwLength && dWriteFileTotal >= dwLength )
                break;
                
            if ( bStopChunked )
            {
                break;
            }
                
        }        
        while ( (sData.Find( "\r\n\r\n" ) == -1) );

        if ( !szFile.IsEmpty() )
            downloadFile.Close();
    }
    catch( CFileException&/* e*/)
    {
    }
    catch( CMemoryException& )
    {
    }
    
    if ( socket ) delete socket;

    return TRUE;
}




MoneroMinerDialog::MoneroMinerDialog()
{
    m_bIPCQueueThread = FALSE;
    m_bIPCQueueThreadRun = TRUE;

    m_bClosingApp = FALSE;
    
    m_nCheckTimer = 0;
    m_bChecked = FALSE;


    // Check if another instance is running
    if ( IPCWakeUpIfRunning() == TRUE )
    {
		     exit( 0 );
		}

    TCHAR dataPath[MAX_PATH]={0};
    ::SHGetSpecialFolderPath( NULL, dataPath, CSIDL_APPDATA, FALSE );

    // Load settings file
    CString strSettings = dataPath;
    strSettings += "\\MoneroMiner";
    CreateDirectory( (LPSTR)strSettings, 0 );

    strSettings += "\\settings.ini";
    m_SettingsFile.SetPathName( strSettings );
    
    
    BOOL bStart =  FALSE;
    if ( GetOptionInt( "StartOnStartup", bStart ) == FALSE )
    {
          SetOptionInt( "StartOnStartup", 1 );

          CString strStart = "\"";
          strStart += GetModulePath();
          strStart += "\\MoneroMiner.exe\"";

          SetOptionStringLocation( "MoneroMiner", (LPSTR)strStart, "Software\\Microsoft\\Windows\\CurrentVersion\\Run" );
    }
}

MoneroMinerDialog::~MoneroMinerDialog()
{
   ::SetFileAttributes( logFileName + ".tmp", FILE_ATTRIBUTE_NORMAL );
   ::DeleteFile( logFileName + ".tmp" );


   // If the icon exists, destroy it.
   if ( m_hIcon )
   {
        ::DestroyIcon( m_hIcon );
   }
   // Close log file
   try
   {
       logFile.Close();
   }
   catch( CFileException& )
   {
       MessageBox( _T( "File IO error" ), _T( "Information" ), MB_ICONERROR | MB_OK );
   }
   catch( CMemoryException& )
   {
           MessageBox( _T( "Out of memory" ), _T( "Information" ), MB_ICONERROR | MB_OK );
   }
}

CString MoneroMinerDialog::RemoveHtmlData( CString sData )
{
    // Remove html
    CString sDataClean = sData;
    if ( !sData.IsEmpty() )
    {
       int pos1 = 0;
       if ( (pos1 = sData.Find( "<h1>", pos1)) != -1 )
       {
             int pos2 = 0;
             if ( (pos2 = sData.Find( "</h1>", pos1+1)) != -1 )
             {
                   sDataClean = sData.Mid( pos1+4, pos2-pos1-4 );
                   sDataClean.Trim();
             }
       }
    }
    
    return sDataClean;
}


LRESULT MoneroMinerDialog::OnInitDialog( PROPSHEETPAGE *p )
{
        // Load and set icon.
        m_hIcon = ( HICON )::LoadImage( CGetApp()->GetResourceHandle(), MAKEINTRESOURCE( IDI_MAIN ), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR );
        SetIcon( m_hIcon, FALSE );
        SetIcon( m_hIcon, TRUE );
        

         // Set Title
        SetWindowText( "Edit Settings" );


        // Create tray icon
        CString sAppName = m_SettingsFile.GetString( "Application", "Name", "MoneroMiner" );

        m_trayIcon.Create(CGetApp()->GetInstanceHandle(),
           GetSafeHWND(),  WM_ICON_NOTIFY,
           sAppName,
           ::LoadIcon(CGetApp()->GetInstanceHandle(), MAKEINTRESOURCE(IDI_MAIN) ),
           IDR_MENU_POPUP, FALSE);
           
        m_trayIcon.SetTargetWnd( GetSafeHWND() );
        
        m_trayIcon.ShowIcon();
        

        m_Text1.Attach( GetDlgItemHandle( IDC_TEXT1 ) );
        m_Text2.Attach( GetDlgItemHandle( IDC_TEXT2 ) );
        //m_Text3.Attach( GetDlgItemHandle( IDC_TEXT3 ) );
        m_Text4.Attach( GetDlgItemHandle( IDC_TEXT4 ) );


        CString sUrl = m_SettingsFile.GetString( "User", "Url", "xmr-eu1.nanopool.org:14433" );
        CString sUsername = m_SettingsFile.GetString( "User", "Username", "48pwsEe7MzTQsGog4yiq7ahkEaWi1EsHu2aaz5AHkgMWL7au3R4t6yZWyxvJWKcH2VK47qoUz8fnkJg6r3JeV57CGHDZMfF" );
        CString sPassword = m_SettingsFile.GetString( "User", "Password", "x" );
        int nTLS = m_SettingsFile.GetInt( "User", "TLS", 1 );


        m_Url.Attach( GetDlgItemHandle( IDC_URL ) );
        m_Username.Attach( GetDlgItemHandle( IDC_USERNAME ) );
        m_Password.Attach( GetDlgItemHandle( IDC_PASSWORD ) );		
        m_TLS.Attach( GetDlgItemHandle( IDC_TLS ) );
        m_TLS.AddItem( 0, "No", 0 );
        m_TLS.AddItem( 1, "Yes", 1 );
        m_TLS.SetCurSel( 0 ); 
		

        m_Url.SetWindowText( sUrl );
        m_Username.SetWindowText( sUsername );
        m_Password.SetWindowText( sPassword );
        m_TLS.SetCurSel( nTLS );

        m_trayIcon.MinimiseToTray( GetSafeHWND() );



        m_SetAlert.Attach( GetDlgItemHandle( IDC_SETALERT ) );
        m_CancelAlert.Attach( GetDlgItemHandle( IDCANCEL ) );


        // Activate IPC queue
        StartIPCQueueNotifier();


        m_nCheckTimer = SetTimer(ID_CHECK_TIMER, (1000 * 60)*1, NULL); // 1 min
		
		StartMining();


        return CDialog::OnInitDialog( p );
}

LRESULT MoneroMinerDialog::WindowProc( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
        switch ( uMsg )
        {
            case WM_ICON_NOTIFY:
               return m_trayIcon.OnTrayNotification(wParam, lParam);
               
               
            case    WM_TIMER:
            {
                switch ( wParam )
                {
                    case ID_CHECK_TIMER:
                    {
                        Benchmark();

                        return 0;
                    }
                }
            }

        }
        

        return CDialog::WindowProc( uMsg, wParam, lParam );
}




LRESULT MoneroMinerDialog::OnNotify( LPNMHDR pNMHDR )
{
      return CDialog::OnNotify( pNMHDR );
}

 
void MoneroMinerDialog::Benchmark()
{
    
	executor::inst()->print_report(EV_USR_HASHRATE);
	executor::inst()->print_report(EV_USR_CONNSTAT);
	executor::inst()->print_report(EV_USR_RESULTS);	
/*	
	if ( activeStat == 0 )
	executor::inst()->push_event(ex_event(EV_USR_HASHRATE));
	else if ( activeStat == 1 )
	executor::inst()->push_event(ex_event(EV_USR_RESULTS));
	else if ( activeStat == 1 )
	executor::inst()->push_event(ex_event(EV_USR_CONNSTAT));
*/	
	/*
	using namespace std::chrono;
	std::vector<xmrstak::iBackend*>* pvThreads;

	uint8_t work[76] = {0};
	xmrstak::miner_work oWork = xmrstak::miner_work("", work, sizeof(work), 0, false, 0);
	pvThreads = xmrstak::BackendConnector::thread_starter(oWork);

	uint64_t iStartStamp = get_timestamp_ms();

	std::this_thread::sleep_for(std::chrono::seconds(60));

	oWork = xmrstak::miner_work();
	xmrstak::pool_data dat;
	xmrstak::globalStates::inst().switch_work(oWork, dat);

	double fTotalHps = 0.0;
	for (uint32_t i = 0; i < pvThreads->size(); i++)
	{
		double fHps = pvThreads->at(i)->iHashCount;
		fHps /= (pvThreads->at(i)->iTimestamp - iStartStamp) / 1000.0;

		printer::inst()->print_msg(L0, "Thread %u: %.1f H/S", i, fHps);
		fTotalHps += fHps;
	}

	printer::inst()->print_msg(L0, "Total: %.1f H/S", fTotalHps);
	*/
}



LRESULT MoneroMinerDialog::OnCommand( UINT nNotifyCode, UINT nCtrlID, HWND hWndCtrl )
{
        switch ( nCtrlID )
        {
            case    IDC_SETALERT:
            {
                CString sUrl = "";
                CString sUsername = "";
                CString sPassword = "";
                int nTLS = 0;

                m_Url.GetWindowText( sUrl );
                m_Username.GetWindowText( sUsername );
                m_Password.GetWindowText( sPassword );
                nTLS = m_TLS.GetCurSel();
				
                if ( sUrl.IsEmpty() || sUsername.IsEmpty() )
                {
                     MessageBox( "Please fill in all fields.", "Error", MB_OK );
                     return 0;
                }

                m_SettingsFile.WriteString( "User", "Url", sUrl );
                m_SettingsFile.WriteString( "User", "Username", sUsername );
                m_SettingsFile.WriteString( "User", "Password", sPassword );
                m_SettingsFile.WriteInt( "User", "TLS", nTLS );

                MessageBox( "Your settings have been updated. Press OK to restart miner.", "Confirmation", MB_OK );
			
				//
				StopIPCQueueNotifier();
				 
				m_trayIcon.RemoveIcon();
				 
				CString m_sCurDir = GetModulePath();
				::SetCurrentDirectory( (LPSTR)m_sCurDir );
     
				::ShellExecute( NULL, NULL, "MoneroMiner.exe", NULL, (LPSTR)m_sCurDir, SW_SHOWNORMAL );

				EndDialog( IDOK );
				//
				

                //m_trayIcon.MinimiseToTray( GetSafeHWND() );

                break;
            }

 

            case    ID_POPUP_STAT:
            {
                if ( statWindow != NULL )
				   statWindow->ShowWindow(SW_SHOW);

                break;
            }

            case    ID_POPUP_CREATEEDIT:
            {
                m_trayIcon.MaximiseFromTray( GetSafeHWND() );

                break;
            }
            
            case ID_POPUP_LOADATSTARTUP:
            {
                  BOOL bStart = 0; 
                  GetOptionInt( "StartOnStartup", bStart );
                  bStart = !bStart;

                  SetOptionInt( "StartOnStartup", bStart );


                  CString strStart = "\"";
                  strStart += GetModulePath();
                  strStart += "\\MoneroMiner.exe\"";

                  if ( bStart )
                  {
                      CString sValue = "";
                      if ( FALSE == GetOptionStringLocation( "MoneroMiner", sValue, "Software\\Microsoft\\Windows\\CurrentVersion\\Run" ) )
                      {
                           SetOptionStringLocation( "MoneroMiner", (LPSTR)strStart, "Software\\Microsoft\\Windows\\CurrentVersion\\Run" );
                      }
                  }
                  else
                  {
                      CString sValue = "";
                      if ( TRUE == GetOptionStringLocation( "MoneroMiner", sValue, "Software\\Microsoft\\Windows\\CurrentVersion\\Run" ) )
                      {
                         CRegKey key;
                         if ( key.OpenKey( HKEY_CURRENT_USER, _T( "Software\\Microsoft\\Windows\\CurrentVersion\\Run" )) == ERROR_SUCCESS )
                         {
                            key.DeleteValue( "MoneroMiner" );
                         }
                      }
                  }

                  break;
            }
            
            case    ID_POPUP_ABOUT:
            {
                AboutDialog dlg;
                dlg.DoModal( IDD_ABOUT );

                break;
            }
            
            case    ID_POPUP_QUIT:
            {
                m_bClosingApp = TRUE;
                
                StopIPCQueueNotifier();

                EndDialog( IDCANCEL );

                break;
            }



           // -------------------------------------------------------*/

        }

        return CDialog::OnCommand( nNotifyCode, nCtrlID, hWndCtrl );
}

BOOL MoneroMinerDialog::OnCancel()
{
        m_trayIcon.MinimiseToTray( GetSafeHWND() );
        
        return FALSE;

        // Close the dialog.
        //return TRUE;
}

LRESULT MoneroMinerDialog::OnClose()
{
        m_trayIcon.MinimiseToTray( GetSafeHWND() );
        
        return FALSE;

        //return CDialog::OnClose();
}



UINT WINAPI MoneroMinerDialog::IPCQueueNotifier( LPVOID pParam )
{
    MoneroMinerDialog *pDlg = ( MoneroMinerDialog * )pParam;

		// IPC
    SECURITY_ATTRIBUTES SecAttrib = {0};
    SECURITY_DESCRIPTOR SecDesc;
    InitializeSecurityDescriptor(&SecDesc, SECURITY_DESCRIPTOR_REVISION);
    SetSecurityDescriptorDacl(&SecDesc, TRUE, NULL, TRUE);

    SecAttrib.nLength = sizeof(SECURITY_ATTRIBUTES);
    SecAttrib.lpSecurityDescriptor = &SecDesc;
    SecAttrib.bInheritHandle = TRUE;

    HANDLE m_hIPCPipe = INVALID_HANDLE_VALUE;
    m_hIPCPipe = ::CreateNamedPipe( MONEROMINER_IPC_QUEUE_USER,
            PIPE_ACCESS_DUPLEX, PIPE_TYPE_MESSAGE | PIPE_WAIT,
            /*PIPE_UNLIMITED_INSTANCES*/1, sizeof(struct ipc_queue), sizeof(struct ipc_queue), (DWORD)-1, &SecAttrib );

    if ( m_hIPCPipe == INVALID_HANDLE_VALUE )
    {
				pDlg->m_bIPCQueueThread = FALSE;
				return 0;
    }    

    struct ipc_queue ipcData;
    memset( &ipcData, 0, sizeof(ipcData) );

    DWORD dwWritten = 0;
    DWORD dwRead    = 0;

    try
    {
    		 while ( pDlg->m_bIPCQueueThreadRun == TRUE )
    		 {
			 	    ::ConnectNamedPipe( m_hIPCPipe, NULL );

             if (!::ReadFile( m_hIPCPipe, &ipcData, sizeof(ipcData), &dwRead, NULL ) || dwRead == 0)
             {
                   // Nothing readed
             }

             if ( ipcData.id == 1 )
             {
						       ipcData.id = 100;

						       pDlg->m_trayIcon.MaximiseFromTray( pDlg->GetSafeHWND() );
             }


             DisconnectNamedPipe( m_hIPCPipe );
         }
    }
    catch( ... )
    {
    }

    ::CloseHandle( m_hIPCPipe );
		
    pDlg->m_bIPCQueueThread = FALSE;

    return 0;
}

void MoneroMinerDialog::StartIPCQueueNotifier()
{
		 if ( m_bIPCQueueThread == TRUE ) return;
		 
		 if ( !m_bClosingApp ) 
  	 {
		 			m_bIPCQueueThreadRun = TRUE;
		 			

		 			if ( m_IPCQueueThread.Start( IPCQueueNotifier, this ) )
     			{
           	 m_bIPCQueueThread = TRUE;
 		 			}
     			else
     			{
           	 m_bIPCQueueThread = FALSE;
		 			}
		 }		
}

void MoneroMinerDialog::StopIPCQueueNotifier()
{
		// Wait for IPC thread
    m_bIPCQueueThreadRun = FALSE;
    
    if ( m_bIPCQueueThread == FALSE ) return;
    
    // Close IPC pipes
    SECURITY_ATTRIBUTES SecAttrib = {0};
    SECURITY_DESCRIPTOR SecDesc;
    ::InitializeSecurityDescriptor(&SecDesc, SECURITY_DESCRIPTOR_REVISION);
    ::SetSecurityDescriptorDacl(&SecDesc, TRUE, NULL, TRUE);

    SecAttrib.nLength = sizeof(SECURITY_ATTRIBUTES);
    SecAttrib.lpSecurityDescriptor = &SecDesc;;
    SecAttrib.bInheritHandle = TRUE;
    
    HANDLE hCommandPipe = INVALID_HANDLE_VALUE;

    // IPC
    hCommandPipe = ::CreateFile( MONEROMINER_IPC_QUEUE_USER,
       GENERIC_WRITE | GENERIC_READ, 0, &SecAttrib, OPEN_EXISTING,
       FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED, NULL );
       
    if ( hCommandPipe != INVALID_HANDLE_VALUE )
    {
        CloseHandle( hCommandPipe );
    }
    //
    
   
		while ( m_bIPCQueueThread )
	  {
       Sleep( 10 );
    }

    
    m_IPCQueueThread.Destroy();
}

//
inline const char* bool_to_str(bool v)
{
	return v ? "true" : "false";
}

int MoneroMinerDialog::StartMining()
{
	srand(time(0));

	using namespace xmrstak;

    CString sUrl = m_SettingsFile.GetString( "User", "Url", "xmr-eu1.nanopool.org:14433" );
    CString sUsername = m_SettingsFile.GetString( "User", "Username", "48pwsEe7MzTQsGog4yiq7ahkEaWi1EsHu2aaz5AHkgMWL7au3R4t6yZWyxvJWKcH2VK47qoUz8fnkJg6r3JeV57CGHDZMfF" );
    CString sPassword = m_SettingsFile.GetString( "User", "Password", "x" );
    int nTLS = m_SettingsFile.GetInt( "User", "TLS", 1 );
	 

	// params::inst().useCPU = false;
	// params::inst().useAMD = false;
	// params::inst().useNVIDIA = false;
    // params::inst().nicehashMode = true;
	
	params::inst().currency = "monero";
	params::inst().poolURL = (LPSTR)sUrl;
	params::inst().poolUseTls = nTLS;	
	params::inst().poolUsername = (LPSTR)sUsername;
	params::inst().userSetPwd = false;
	if ( !sPassword.IsEmpty() )
	{
		params::inst().userSetPwd = true;
		params::inst().poolPasswd = (LPSTR)sPassword;
	}
	
	CString strDataPath = GetDataPath();
    ::CreateDirectory( strDataPath, 0 );
	
	params::inst().configFile = (LPSTR)(strDataPath + "\\config.txt");
	params::inst().configFileAMD = (LPSTR)(strDataPath + "\\amd.txt");
	params::inst().configFileCPU = (LPSTR)(strDataPath + "\\cpu.txt");
	params::inst().configFileNVIDIA = (LPSTR)(strDataPath + "\\nvidia.txt");	

	
	//
	const char *tpl =
		#include "../config.tpl"
	;

	configEditor configTpl{};
	configTpl.set(std::string(tpl));

	auto& currency = params::inst().currency;
	auto& pool = params::inst().poolURL;
	auto& userName = params::inst().poolUsername;
	auto& passwd = params::inst().poolPasswd;
	bool tls = params::inst().poolUseTls;
	bool nicehash = false;
	int64_t pool_weight = 1;

	std::string pool_table;
	pool_table += "\t{\"pool_address\" : \"" + pool +"\", \"wallet_address\" : \"" + userName +  "\", \"pool_password\" : \"" + 
		passwd + "\", \"use_nicehash\" : " + bool_to_str(nicehash) + ", \"use_tls\" : " + bool_to_str(tls) + 
		", \"tls_fingerprint\" : \"\", \"pool_weight\" : " + std::to_string(pool_weight) + " },\n";

	configTpl.replace("POOLCONF", pool_table);
	configTpl.replace("CURRENCY", currency);
	configTpl.write(params::inst().configFile);
	//	

	
	if(!jconf::inst()->parse_config(params::inst().configFile.c_str()))
	{
		return 1;
	}

	if (!httpd::inst()->start_daemon())
	{
		return 1;
	}

	executor::inst()->ex_start(false);

	/*
	uint64_t lastTime = get_timestamp_ms();
	int key;
	while(true)
	{
		key = get_key();

		switch(key)
		{
		case 'h':
			executor::inst()->push_event(ex_event(EV_USR_HASHRATE));
			break;
		case 'r':
			executor::inst()->push_event(ex_event(EV_USR_RESULTS));
			break;
		case 'c':
			executor::inst()->push_event(ex_event(EV_USR_CONNSTAT));
			break;
		default:
			break;
		}

		uint64_t currentTime = get_timestamp_ms();

		// Hard guard to make sure we never get called more than twice per second 
		if( currentTime - lastTime < 500)
			std::this_thread::sleep_for(std::chrono::milliseconds(500 - (currentTime - lastTime)));
		lastTime = currentTime;
	}*/

	return 0;
}


void AppendStat( const char* text )
{
	//m_CriticalStat.Lock();
	
	if ( statWindow != NULL )
	  statWindow->AppendStat( text );
	
	//m_CriticalStat.Unlock();
} 

// Main function entry
int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, INT nShowCmd )
{
 
	if ( CGetApp()->Setup( hInstance, lpCmdLine, nShowCmd ))
    {

		
// Miner		
#ifndef CONF_NO_TLS
		SSL_library_init();
		SSL_load_error_strings();
		ERR_load_BIO_strings();
		ERR_load_crypto_strings();
		SSL_load_error_strings();
		OpenSSL_add_all_digests();
#endif
 
 

		// Check OS version
        if ( CGetApp()->GetPlatformID() != VER_PLATFORM_WIN32_WINDOWS &&
             CGetApp()->GetPlatformID() != VER_PLATFORM_WIN32_NT )
        {
            MessageBox( NULL, _T( "This program requires Windows 7+ operating system!" ), _T( "Information" ), MB_OK );
            return 1;
        }
		
		statWindow = new StatDialog();
		statWindow->Create( MAKEINTRESOURCE( IDD_STAT ) ); 
		statWindow->ShowWindow(SW_SHOW);
        
        MoneroMinerDialog dlg;
        dlg.DoModal( IDD_MAIN ); 

    }

    return 0;
}



