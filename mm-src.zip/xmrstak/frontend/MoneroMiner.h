#if !defined(MONEROMINER_H)
#define MONEROMINER_H

#include "classes/include/all.h"

#include "resource.h"


#define WM_ICON_NOTIFY                  WM_APP  + 10
#define WM_NEW_PLUG                     WM_APP  + 11




#endif
