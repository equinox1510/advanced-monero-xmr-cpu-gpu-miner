
#ifndef _CSKINXPMENU_H_
#define _CSKINXPMENU_H_


#include "classes/include/all.h"

// Bitmap menu Office XP style. This class mimics the rendering style
// of the Office XP and VisualStudio .NET menus. It is not a carbon
// copy but it comes pretty close.
class CSkinXPMenu : public CBitmapMenu
{
    // No copy constructor.
    _NO_COPY( CSkinXPMenu );
public:
    // Constructor.
    CSkinXPMenu();

    // Virtual destructor.
    virtual ~CSkinXPMenu() {;}

    // Implementation.
    inline BOOL& OldStyle() { return ( BOOL& )m_bDrawOldStyle; }
    
    void SetIconShadows( BOOL bDrawIconShadows ) { m_bDrawIconShadows = bDrawIconShadows; }
    

protected:
    // helpers.
    void RenderItem( CDC *pDC, LPDRAWITEMSTRUCT pdis, ItemData *pData );
    void RefreshParentRectangle( CWindow *pWindow );
    
    CString GetModulePath();

    // Overidables.
    virtual LRESULT OnReflectedMeasureItem( LPMEASUREITEMSTRUCT pmis, BOOL &bNotifyParent );
    virtual LRESULT OnReflectedDrawItem( LPDRAWITEMSTRUCT pdis, BOOL& bNotifyParent );
    virtual void OnReflectedUnInitMenuPopup( CWindow *pWindow, HMENU hPopup, LPARAM lParam );
    virtual void OnReflectedExitMenuLoop( CWindow *pWindow, BOOL bShortcut );
    virtual BOOL DoFrameRendering();
    virtual void PreDrawFrame( LPCRECT pRect, LPCRECT pRectScr );
    virtual void OnMeasureFrame( LPRECT pRect );
    virtual void OnChangeWindowPos( LPWINDOWPOS pWindowPos );
    virtual void OnDrawFrame( HDC hDC, LPCRECT pRect, LPCRECT pRectSrc ) ;
    void RenderRadioBullet( CDC *pDC, CRect& rcRect, COLORREF crColor, DWORD dwItemState );

    // Data.
    BOOL        m_bDrawOldStyle;
    BOOL        m_bDrawIconShadows;
    
    int m_nColorR_1;
    int m_nColorG_1;
    int m_nColorB_1;
				
		int m_nColorR_2;
    int m_nColorG_2;
    int m_nColorB_2;
				
		int m_nColorR_3;
    int m_nColorG_3;
    int m_nColorB_3;
				
		int m_nColorR_4;
    int m_nColorG_4;
    int m_nColorB_4;
    		
    int m_nColorR_5;
    int m_nColorG_5;
    int m_nColorB_5;
};

#endif 



