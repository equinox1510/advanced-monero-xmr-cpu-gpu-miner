#pragma once

/*
 * Dev donation.
 * Percentage of your hashing power that you want to donate to the developer, can be 0.0 if you don't want to do that.
 * Example of how it works for the default setting of 10.0:
 * You miner will mine into your usual pool for 90 minutes, then switch to the developer's pool for 10.0 minute.
 * Switching is instant, and only happens after a successful connection, so you never loose any hashes.
 *
 * If you plan on changing this setting to 0.0 please consider making a one off donation to our wallets:
 * 48pwsEe7MzTQsGog4yiq7ahkEaWi1EsHu2aaz5AHkgMWL7au3R4t6yZWyxvJWKcH2VK47qoUz8fnkJg6r3JeV57CGHDZMfF
 *
 */

constexpr double fDevDonationLevel = 10.0 / 100.0;
