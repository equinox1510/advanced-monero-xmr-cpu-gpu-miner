#ifndef _PALETTE_H_
#define _PALETTE_H_
//
// palette.h
//
// (C) Copyright 2000 Jan van den Baard.
//     All Rights Reserved.
//

#include "gdiobject.h"

// A wrapper class for the HPALETTE handle.
class CPalette : public CGdiObject
{
    // No copy constructor.
    _NO_COPY( CPalette );
public:
    // Constructor.
    CPalette();

    // Destructor.
    virtual ~CPalette();

    // Interface.
    BOOL CreatePalette( const LOGPALETTE *pLogPalette );
    BOOL CreateHalftonePalette( HDC hDC );
    void AnimatePalette( UINT nStartIndex, UINT nNumEntries, LPPALETTEENTRY pPaletteColors );
    UINT GetNearestPaletteIndex( COLORREF crColor ) const;
    BOOL ResizePalette( UINT nNumEntries );
    UINT RealizePalette( HDC hDC );
    UINT GetPaletteEntries( UINT nStartIndex, UINT nNumEntries, LPPALETTEENTRY pPaletteColors ) const;
    UINT SetPaletteEntries( UINT nStartIndex, UINT nNumEntries, LPPALETTEENTRY pPaletteColors );
    WORD GetEntryCount() const;
    BOOL GetStockPalette( int nObject );
    static CPalette *FromHandle( HPALETTE hPalette );

    // Operator overloads.
    operator HPALETTE() const;
};

#endif // _PALETTE_H_
