//
// dc.cpp
//
// (C) Copyright 2000 Jan van den Baard.
//     All Rights Reserved.
//

#include "dc.h"
#include "brush.h"
#include "pen.h"
#include "selector.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Global list of device context object.
CLinkedList<CDC>    global_dc_list;
CLinkedList<CDC>    temporary_dc_list;

// Count the created DC's.
#ifdef _DEBUG
int nDCObjects = 0;
#endif

// Static dc functions pointers. These are OS dependant...
typedef BOOL ( CALLBACK *GRADIENTFILL )( HDC, CONST PTRIVERTEX, DWORD, CONST PVOID, DWORD, DWORD );

static GRADIENTFILL StaticGradientFill = NULL;

// Finds a device context object in the list by it's handle
// value.
static CDC *CFindObjectByHandle( CLinkedList<CDC>& list, HDC hDC )
{
    _ASSERT_VALID( hDC ); // This must be valid.

    // Iterate the nodes.
    for ( CDC *pDC = list.GetFirst(); pDC; pDC = list.GetNext( pDC ))
    {
        // Is the handle wrapped by this object
        // the one we are looking for?
        if ( *pDC == hDC )
            // Yes. Return a pointer to the object.
            return pDC;
    }
    // Object not in the list.
    return NULL;
}

// Constructor.
CDC::CDC()
{
    // Clear handle.
    m_hDC = NULL;

    // Add us to the global list.
    global_dc_list.AddHead( this );
}

// Constructor. Initializes to a handle.
CDC::CDC( HDC hDC )
{
    _ASSERT_VALID( hDC ); // Must be valid.

    // Clear handle.
    m_hDC = NULL;

    // Attach the handle.
    Attach( hDC );

    // Add us to the global list.
    global_dc_list.AddHead( this );
}

// Destructor.
CDC::~CDC()
{
    // The destructor does nothing so
    // you are responsible for calling
    // DeleteDC() or ReleaseDC().
    //_ASSERT( m_hDC == NULL );

    // Remove us from the list if we are still
    // in there.
    CDC *pDC;
    for ( pDC = global_dc_list.GetFirst(); pDC; pDC = global_dc_list.GetNext( pDC ))
    {
        // Is this us?
        if ( pDC == this )
        {
            // Yes. Remove us from the list.
            global_dc_list.Remove( pDC );
            break;
        }
    }
}

// Detach the handle.
HDC CDC::Detach()
{
    _ASSERT_VALID( m_hDC );

    // Save handle.
    HDC hDC = m_hDC;

    // Set it to NULL.
    m_hDC = NULL;

    // Return the handle.
    return hDC;
}

// Attach a handle to this object. Only works
// if the object is empty.
BOOL CDC::Attach( HDC hDC )
{
    _ASSERT( m_hDC == NULL ); // The object must be empty.
    _ASSERT_VALID( hDC );

    // Can we attach the handle?
    if ( m_hDC == NULL )
    {
        // Attach it.
        m_hDC = hDC;
        return TRUE;
    }
    return FALSE;
}

BOOL CDC::CreateDC( LPCTSTR lpszDriverName, LPCTSTR lpszDeviceName, LPCTSTR lpszOutput, const DEVMODE *lpInitData )
{
    _ASSERT( m_hDC == NULL ); // The object must be empty.

    // Can we create the handle?
    if ( m_hDC == NULL )
    {
        // Attach the handle.
        if ( Attach( ::CreateDC( lpszDriverName, lpszDeviceName, lpszOutput, lpInitData )))
        {
            #ifdef _DEBUG
            nDCObjects++;
            #endif
            return TRUE;
        }
    }
    return FALSE;
}

BOOL CDC::CreateIC( LPCTSTR lpszDriverName, LPCTSTR lpszDeviceName, LPCTSTR lpszOutput, const DEVMODE *lpInitData )
{
    _ASSERT( m_hDC == NULL ); // The object must be empty.

    // Can we create the handle?
    if ( m_hDC == NULL )
    {
        // Attach the handle.
        if ( Attach( ::CreateIC( lpszDriverName, lpszDeviceName, lpszOutput, lpInitData )))
        {
            #ifdef _DEBUG
            nDCObjects++;
            #endif
            return TRUE;
        }
    }
    return FALSE;
}

BOOL CDC::CreateCompatibleDC( CDC *pDC )
{
    _ASSERT( m_hDC == NULL ); // The object must be empty.

    // Can we create the handle?
    if ( m_hDC == NULL )
    {
        // Attach the handle.
        if ( Attach( ::CreateCompatibleDC( pDC ? pDC->m_hDC : NULL )))
        {
            #ifdef _DEBUG
            nDCObjects++;
            #endif
            return TRUE;
        }
    }
    return FALSE;
}

BOOL CDC::DeleteDC()
{
    _ASSERT_VALID( m_hDC ); // Object must be valid.

    // Delete the device context.
    BOOL bRC = ::DeleteDC( m_hDC );

    // OK?
    if ( bRC )
    {
        #ifdef _DEBUG
        nDCObjects--;
        #endif
        // Clear handle.
        m_hDC = NULL;
    }

    // Return error flag.
    return bRC;
}

CDC *CDC::FromHandle( HDC hDC )
{
    CDC    *pDC = NULL;

    // Valid?
    if ( hDC == NULL )
        return NULL;
        

    // Do we have it in the global list?
    if (( pDC = CFindObjectByHandle( global_dc_list, hDC )) == NULL )
    {
        // No, see if we can find it in the temporary list.
        if (( pDC = CFindObjectByHandle( temporary_dc_list, hDC )) == NULL )
        {
            // No. Create a temporary new object
            // and add it to the temporary list.
            pDC = new CDC( hDC );
            global_dc_list.Remove( pDC );
            temporary_dc_list.AddHead( pDC );
        }
    }
    return pDC;
}

void CDC::DeleteTempObjects()
{
    // Iterate temporary objects deleting
    // them.
    CDC *pDC;
    while (( pDC = temporary_dc_list.RemoveHead()) != NULL )
    {
        // Detach the handle from the temporary object.
        pDC->Detach();
        delete pDC;
    }
}

CBitmap *CDC::GetCurrentBitmap() const
{
    _ASSERT_VALID( m_hDC ); // Must be valid.

    // Get the device context bitmap.
    HBITMAP    hBitmap = ( HBITMAP )::GetCurrentObject( m_hDC, OBJ_BITMAP );

    // If it is valid we create a temporary object of
    // it.
    return CBitmap::FromHandle( hBitmap );
}

CBrush *CDC::GetCurrentBrush() const
{
    _ASSERT_VALID( m_hDC ); // Must be valid.

    // Get the device context brush.
    HBRUSH    hBrush = ( HBRUSH )::GetCurrentObject( m_hDC, OBJ_BRUSH );

    // If it is valid we create a temporary object of
    // it.
    return CBrush::FromHandle( hBrush );
}

CFont *CDC::GetCurrentFont() const
{
    _ASSERT_VALID( m_hDC ); // Must be valid.

    // Get the device context font.
    HFONT    hFont = ( HFONT )::GetCurrentObject( m_hDC, OBJ_FONT );

    // If it is valid we create a temporary object of
    // it.
    return CFont::FromHandle( hFont );
}

CPalette *CDC::GetCurrentPalette() const
{
    _ASSERT_VALID( m_hDC ); // Must be valid.

    // Get the device context palette.
    HPALETTE hPalette = ( HPALETTE )::GetCurrentObject( m_hDC, OBJ_PAL );

    // If it is valid we create a temporary object of
    // it.
    return CPalette::FromHandle( hPalette );
}

CPen *CDC::GetCurrentPen() const
{
    _ASSERT_VALID( m_hDC ); // Must be valid.

    // Get the device context pen.
    HPEN hPen = ( HPEN )::GetCurrentObject( m_hDC, OBJ_PEN );

    // If it is valid we create a temporary object of
    // it.
    return CPen::FromHandle( hPen );
}

CPalette *CDC::SelectPalette( CPalette *pPalette, BOOL bForceBackground )
{
    _ASSERT_VALID( m_hDC ); // Must be valid.

    // Select the palette.
    HPALETTE hPal = ::SelectPalette( m_hDC, *pPalette, bForceBackground );

    // OK?
    if ( hPal )
        // Create temp object.
        return CPalette::FromHandle( hPal );
    return NULL;
}

// GradientFill() API.
BOOL CDC::GradientFill( TRIVERTEX* pVertices, ULONG nVertices, void* pMesh, ULONG nMeshElements,  DWORD dwMode )
{
    _ASSERT_VALID( m_hDC ); // Must be valid.

    // Function known?
    if ( StaticGradientFill )
        return ( *StaticGradientFill )( m_hDC, pVertices, nVertices, pMesh, nMeshElements, dwMode );
    
    // Get the procedure address.
    StaticGradientFill = ( GRADIENTFILL )GetProcAddress( GetModuleHandle( _T( "msimg32.dll" )), "GradientFill" );
    if ( StaticGradientFill )
        return ( *StaticGradientFill )( m_hDC, pVertices, nVertices, pMesh, nMeshElements, dwMode );
    return FALSE;
}

// Render an outlined rectangle.
void CDC::OutlinedRectangle( LPCRECT pRect, COLORREF crOuter, COLORREF crInner )
{
    _ASSERT_VALID( m_hDC );

    // Create GDI objects.
    CBrush inner( crInner );
    CPen outer( PS_SOLID, 1, crOuter );

    // Select them into the DC.
    CSelector bsel( this, inner );
    CSelector psel( this, outer );

    // Render rectangle.
    Rectangle( pRect );
}

// Fill a solid rectangle.
void CDC::FillSolidRect( LPCRECT lpRect, COLORREF crColor )
{
    CBrush brush( crColor );
    if ( brush.IsValid()) FillRect( lpRect, brush );
}

void CDC::FillSolidRect( int x, int y, int cx, int cy, COLORREF crColor )
{
    CBrush brush( crColor );
    if ( brush.IsValid()) FillRect( CRect( x, y, x + cx, y + cy ), brush );
}
