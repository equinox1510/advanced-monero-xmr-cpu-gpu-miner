#ifndef _LRADIOBUTTON_H_
#define _LRADIOBUTTON_H_
//
// lradiobutton.h
//
// (C) Copyright 2000 Jan van den Baard.
//     All Rights Reserved.
//

#include "../windows/controls/radiobutton.h"
#include "../gdi/getdc.h"
#include "../gdi/selector.h"
#include "../strings/string.h"

// A simple radion button control for the layout engine.
class CLRadioButton : public CRadioButton
{
    _NO_COPY( CLRadioButton );
public:
    // Constructor.
    CLRadioButton() {;}

    // Destructor.
    virtual ~CLRadioButton() {;}

protected:
    // Compute the radiobutton it's minimum size.
    virtual BOOL OnGetMinSize( CSize& szMinSize )
    {
        // Setup radio button width.
        szMinSize.CX() = ::GetSystemMetrics( SM_CXMENUCHECK ) + ( 4 * ::GetSystemMetrics( SM_CXEDGE ));        
    
        // Measure caption.
        CGetDC    dc( this );
        CString    str( GetSafeHWND());

        // Any caption?
        if ( str.GetStringLength())
        {
            // Setup the font to use.
            CSelector sel( &dc, ( HFONT )SendMessage( WM_GETFONT ));

            // Add the size of the caption.
            szMinSize.Add( dc.GetTextExtent( str ));

            // Take the largest. Either the text height or the
            // button height.
            int nHeight = ::GetSystemMetrics( SM_CYMENUCHECK );
            if ( nHeight > szMinSize.CY())
                szMinSize.CY() = nHeight;
        }
        return TRUE;
    }
};

#endif // _LRADIOBUTTON_H_
