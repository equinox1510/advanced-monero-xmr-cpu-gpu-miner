#ifndef _LLISTBOX_H_
#define _LLISTBOX_H_
//
// llistbox.h
//
// (C) Copyright 2000 Jan van den Baard.
//     All Rights Reserved.
//

#include "../windows/controls/listbox.h"
#include "../gdi/getdc.h"
#include "../gdi/selector.h"
#include "../strings/string.h"

// A simple listbox control for the layout engine.
class CLListBox : public CListBox
{
    _NO_COPY( CLListBox );
public:
    // Constructor.
    CLListBox() {;}

    // Destructor.
    virtual ~CLListBox() {;}

protected:
    // Compute the listbox control it's minimum size.
    // Note that this code will not work for ownerdraw
    // controls.
    virtual BOOL OnGetMinSize( CSize& szMinSize )
    {
        // Get the width and height of a simple six
        // character string.
        CGetDC dc( this );

        // Setup the font to use.
        CSelector sel( &dc, ( HFONT )SendMessage( WM_GETFONT ));
        
        // Measure it.
        szMinSize = dc.GetTextExtent( _T( "MXWMXW" ), 6 );

        // Show at least three items.
        szMinSize.CY() *= 3;

        // Add the scroller width.
        szMinSize.CX() += GetSystemMetrics( SM_CXHSCROLL );

        // Add frame sizes.
        DWORD dwExStyle = GetExStyle();
        if (( dwExStyle & WS_EX_CLIENTEDGE ) == WS_EX_CLIENTEDGE ) 
        {
            szMinSize.CX() += ::GetSystemMetrics( SM_CXEDGE ) * 4;
            szMinSize.CY() += ::GetSystemMetrics( SM_CYEDGE ) * 2;
        }
        return TRUE;
    }
};

#endif // _LLISTBOX_H_
