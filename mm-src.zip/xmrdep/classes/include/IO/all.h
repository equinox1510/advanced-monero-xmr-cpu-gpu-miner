#ifndef _IO_ALL_H_
#define _IO_ALL_H_
//
// all.h
//
// (C) Copyright 1999-2001 Jan van den Baard
//     All Rights Reserved.
//

#include "file.h"
#include "stdiofile.h"

#endif // _IO_ALL_H_