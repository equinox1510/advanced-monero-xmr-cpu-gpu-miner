#ifndef _XPMENU_H_
#define _XPMENU_H_
//
// xpmenu.h
//
// (C) Copyright 2002 Jan van den Baard.
//     All Rights Reserved.
//

#include "bitmapmenu.h"
#include "../tools/xpcolors.h"
#include "../gdi/dc.h"
#include "../gdi/bitmap.h"
#include "../coords/rect.h"

// Bitmap menu Office XP style. This class mimics the rendering style
// of the Office XP and VisualStudio .NET menus. It is not a carbon
// copy but it comes pretty close.
class CXPMenu : public CBitmapMenu
{
    // No copy constructor.
    _NO_COPY( CXPMenu );
public:
    // Constructor.
    CXPMenu() : m_bDrawOldStyle( FALSE ),
                m_bDrawIconShadows( FALSE )
                {;}

    // Virtual destructor.
    virtual ~CXPMenu() {;}

    // Implementation.
    inline BOOL& OldStyle() { return ( BOOL& )m_bDrawOldStyle; }
    
    void SetIconShadows( BOOL bDrawIconShadows ) { m_bDrawIconShadows = bDrawIconShadows; }
    

protected:
    // helpers.
    void RenderItem( CDC *pDC, LPDRAWITEMSTRUCT pdis, ItemData *pData );
    void RefreshParentRectangle( CWindow *pWindow );

    // Overidables.
    virtual LRESULT OnReflectedMeasureItem( LPMEASUREITEMSTRUCT pmis, BOOL &bNotifyParent );
    virtual LRESULT OnReflectedDrawItem( LPDRAWITEMSTRUCT pdis, BOOL& bNotifyParent );
    virtual void OnReflectedUnInitMenuPopup( CWindow *pWindow, HMENU hPopup, LPARAM lParam );
    virtual void OnReflectedExitMenuLoop( CWindow *pWindow, BOOL bShortcut );
    virtual BOOL DoFrameRendering();
    virtual void PreDrawFrame( LPCRECT pRect, LPCRECT pRectScr );
    virtual void OnMeasureFrame( LPRECT pRect );
    virtual void OnChangeWindowPos( LPWINDOWPOS pWindowPos );
    virtual void OnDrawFrame( HDC hDC, LPCRECT pRect, LPCRECT pRectSrc ) ;
    void RenderRadioBullet( CDC *pDC, CRect& rcRect, COLORREF crColor, DWORD dwItemState );

    // Data.
    BOOL        m_bDrawOldStyle;
    BOOL        m_bDrawIconShadows;
};

#endif // _XPMENU_H_
