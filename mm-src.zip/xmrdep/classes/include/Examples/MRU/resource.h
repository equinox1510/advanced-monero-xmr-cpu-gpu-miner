//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MRU.RC
//
#define IDD_MRU                         101
#define ID_FILE_FUCK                    103
#define ID_FILES                        105
#define ID_FILES_SUBMENU                106
#define IDB_BITMAP1                     107
#define IDC_ADD                         1000
#define IDC_REM                         1001
#define IDC_SHOW                        1002
#define IDC_SAVE                        1003
#define IDC_OFFICE_XP                   1005
#define IDC_ABOUT                       1006
#define IDC_FILEICONS                   1007
#define IDC_COMBO1                      1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
