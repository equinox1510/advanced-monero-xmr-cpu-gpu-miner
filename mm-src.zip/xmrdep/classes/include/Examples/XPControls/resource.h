//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by XPControls.rc
//
#define IDD_XPC                         9
#define IDC_EDIT_1                      1001
#define IDC_EDIT_2                      1002
#define IDC_COMBO_1                     1004
#define IDC_COMBO_2                     1005
#define IDC_COMBO_3                     1006
#define IDC_COMBO_4                     1007
#define IDC_OK                          1008
#define IDC_OK_1                        1008
#define IDC_OK_2                        1009
#define IDC_CHECK1                      1010
#define IDC_DISABLE                     1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
