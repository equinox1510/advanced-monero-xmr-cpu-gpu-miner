//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FastFind.rc
//
#define IDD_FIF                         101
#define IDI_FIND                        102
#define IDC_FIND                        1000
#define IDC_TYPES                       1001
#define IDC_FOLDER                      1002
#define IDC_LIST                        1004
#define IDC_CASE                        1005
#define IDC_GO                          1006
#define IDC_RECUR                       1007
#define IDC_OCC                         1008
#define IDC_PROC                        1014
#define IDC_STATIC_1                    1015
#define IDC_STATIC_2                    1016
#define IDC_STATIC_3                    1017
#define IDC_STATIC_4                    1018
#define IDC_STATIC_5                    1019
#define IDC_STATIC_6                    1020
#define IDC_STATIC_7                    1021
#define IDC_ABOUT                       1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
