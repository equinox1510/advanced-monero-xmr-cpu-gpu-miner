//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CRC.rc
//
#define IDD_CRC                         101
#define IDC_POLY                        1000
#define IDC_FILE                        1000
#define IDC_GEN32                       1001
#define IDC_GEN16                       1002
#define IDC_TABLE                       1003
#define IDC_CRC                         1004
#define IDC_SETCRC                      1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
