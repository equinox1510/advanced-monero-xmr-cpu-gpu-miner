//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by LayoutEngine.rc
//
#define IDD_LAYOUT                      101
#define IDI_ICON                        102
#define ID_FILE_OPEN104                 104
#define ID_FILE_EXIT                    105
#define IDC_GRID1                       999
#define IDC_GRID2                       1000
#define IDC_GRID3                       1001
#define IDC_GRID4                       1002
#define IDC_GRID5                       1003
#define IDC_GRID6                       1004
#define IDC_GRID7                       1005
#define IDC_GRID8                       1006
#define IDC_GRID9                       1007
#define IDC_VERT1                       1008
#define IDC_VERT2                       1009
#define IDC_VERT3                       1010
#define IDC_HORZ1                       1011
#define IDC_HORZ2                       1012
#define IDC_HORZ3                       1013
#define IDC_25                          1015
#define IDC_50                          1016
#define IDC_75                          1017
#define IDC_100                         1018
#define IDC_FREE1                       1019
#define IDC_FIXED1                      1020
#define IDC_FREE2                       1021
#define IDC_FIXED2                      1022
#define IDC_OK                          1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
