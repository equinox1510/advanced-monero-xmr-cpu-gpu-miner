//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by InfoBar.rc
//
#define IDI_ICON                       100
#define IDD_INFOBAR                    101
#define IDI_RIGHT                      102
#define IDI_LEFT                       103
#define IDI_TOP                        104
#define IDI_BOTTOM                     105
#define IDC_HORIZTOP                   200
#define IDC_VERTTOP                    201
#define IDC_HORIZBOTTOM                202
#define IDC_VERTBOTTOM                 203
#define IDC_HORIZRIGHT                 1000
#define IDC_OK                         1004
#define IDC_HORIZLEFT                  1005
#define IDC_DESC                       1006

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS               1
#define _APS_NEXT_RESOURCE_VALUE       106
#define _APS_NEXT_CONTROL_VALUE        1007
#define _APS_NEXT_SYMED_VALUE          1107
#define _APS_NEXT_COMMAND_VALUE        0
#endif
#endif
