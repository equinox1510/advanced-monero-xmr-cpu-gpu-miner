#ifndef _COORDS_ALL_H_
#define _COORDS_ALL_H_
//
// all.h
//
// (C) Copyright 1999-2001 Jan van den Baard
//     All Rights Reserved.
//

// Simply include all headers in this directory.
#include "point.h"
#include "rect.h"
#include "size.h"

#endif // _COORDS_ALL_H_