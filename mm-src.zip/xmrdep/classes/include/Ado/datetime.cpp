//
// datetime.cpp
//
// (C) Copyright 2003 Jan van den Baard.
//     All Rights Reserved.
//

#include "datetime.h"
#include <time.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Constructor, SYSTEMTIME.
CDateTime::CDateTime( const LPSYSTEMTIME pst )
{ 
    // Convert.
    m_status = valid;
    if ( ! ::SystemTimeToVariantTime( pst, &m_date ))
        // Invalidate this.
        m_status = invalid;
}

// Constructor, initializes to either 0 or the current
// system time.
CDateTime::CDateTime( BOOL bSystemTime /* = FALSE */ )
{
    // Initialize to the system time?
    m_status = valid;
    if ( bSystemTime )
    {
        // Get the system time.
        SYSTEMTIME st;
        ::GetSystemTime( &st );

        // Make the conversion.
        if ( ! ::SystemTimeToVariantTime( &st, &m_date ))
            // Invalidate this.
            m_status = invalid;
    }
    else
        // 0 means 30 December 1899, midnight
        m_date = 0.0;
}

// Constructor, copy.
CDateTime::CDateTime( const CDateTime& dtSrc )
{ 
    // Copy status and value.
    m_status = dtSrc.m_status; 
    m_date = dtSrc.m_date; 
}

// Constructor, values.
CDateTime::CDateTime( int nYear, int nMonth, int nDay, int nHour, int nMin, int nSec )
{ 
    // Initialize object.
    SetDateTime( nYear, nMonth, nDay, nHour, nMin, nSec ); 
}

// Constructor, DATE.
CDateTime::CDateTime( DATE dtSrc )
{ 
    // Validate and set value.
    m_status = valid; 
    m_date = dtSrc; 
}

// Constructor, VARIANT.
CDateTime::CDateTime( const VARIANT& vt )
{ 
    // Assign value.
    *this = vt;  
}

// Destructor, no-op.
CDateTime::~CDateTime()
{
}

// Convert to a SYSTEMTIME.
BOOL CDateTime::GetAsSystemTime( SYSTEMTIME& st ) const
{ 
    // Perform conversion.
    return ( BOOL )::VariantTimeToSystemTime( m_date, &st ); 
}

// Convert to a DBTIMESTAMP.
BOOL CDateTime::GetAsDBTIMESTAMP( DBTIMESTAMP& dbt ) const
{
    // Convert to a UDATE structure.
    UDATE udt;
    if ( m_status == valid && ::VarUdateFromDate( m_date, 0, &udt ) == S_OK )
    {
        // Copy values into a DBTIMESTAMP structure.
        dbt.day        = udt.st.wDay;
        dbt.fraction    = 0;
        dbt.hour    = udt.st.wHour;
        dbt.minute    = udt.st.wMinute;
        dbt.month    = udt.st.wMonth;
        dbt.second    = udt.st.wSecond;
        dbt.year    = udt.st.wYear;
        return TRUE;
    }
    return FALSE;
}

// Return as UDATE.
BOOL CDateTime::GetAsUDATE( UDATE& udt ) const
{ 
    // Convert...
    return ( BOOL )( ::VarUdateFromDate( m_date, 0, &udt ) == S_OK );
}

// Obtain the day.
int CDateTime::GetDay() const
{
    SYSTEMTIME st; 
    return GetAsSystemTime( st ) ? st.wDay : -1; 
}

// Obtain the day of the week.
int CDateTime::GetDayOfWeek() const
{ 
    SYSTEMTIME st; 
    return GetAsSystemTime( st ) ? st.wDayOfWeek + 1 : -1; 
}

// Get the day of the year.
int CDateTime::GetDayOfYear() const
{ 
    UDATE udt;
    return GetAsUDATE( udt ) ? udt.wDayOfYear : -1;
}

// Get the hour.
int CDateTime::GetHour() const
{ 
    SYSTEMTIME st; 
    return GetAsSystemTime( st ) ? st.wHour : -1; 
}

// Get the minute.
int CDateTime::GetMinute() const
{ 
    SYSTEMTIME st; 
    return GetAsSystemTime( st ) ? st.wMinute : -1; 
}

// Get the second.
int CDateTime::GetSecond() const
{ 
    SYSTEMTIME st; 
    return GetAsSystemTime( st ) ? st.wSecond : -1; 
}

// Get the year.
int CDateTime::GetYear() const
{ 
    SYSTEMTIME st; 
    return GetAsSystemTime( st ) ? st.wYear : -1; 
}

// Format the date/time into a string.
CString CDateTime::Format( DWORD dwFlags /* = 0 */, LCID lcid /* = LANG_USER_DEFAULT */ ) const
{
    // Format the output.
    _bstr_t bstr;
    CString str;
    if ( ::VarBstrFromDate( m_date, lcid, dwFlags, &bstr.GetBSTR()) == S_OK )
        // Assign the formatted output.
        str = ( LPCTSTR )bstr;

    // Return the result.
    return str;
}

// Format the date/time into a string.
CString CDateTime::Format( LPCTSTR pszFormat ) const
{
    // Convert the date.time to an UDATE format.
    TCHAR sz[ 512 ] = { 0 };
    UDATE udt;
    
    // Do the conversion to UDATE.
    if ( GetAsUDATE( udt ))
    {
        // Convert the UDATE to a tm structure.
        struct tm    tm;
        tm.tm_hour    = udt.st.wHour;
        tm.tm_isdst    = 0;
        tm.tm_mday    = udt.st.wDay;
        tm.tm_min    = udt.st.wMinute;
        tm.tm_mon    = udt.st.wMonth - 1;
        tm.tm_sec    = udt.st.wSecond;
        tm.tm_wday    = udt.st.wDayOfWeek;
        tm.tm_yday    = udt.wDayOfYear - 1;
        tm.tm_year    = udt.st.wYear - 1900;
        
        // Convert to the temporary buffer and then assign
        // to the result string.
        _tcsftime( sz, 512, pszFormat, &tm );
    }
    return CString( sz );
}

// Format the date/time into a string specified by the
// resource identifier.
CString CDateTime::Format( UINT nFormatID ) const
{
    CString str( MAKEINTRESOURCE( nFormatID ));
    return Format( str );
}

// Set the date/time to the specified values.
BOOL CDateTime::SetDateTime( int nYear, int nMonth, int nDay, int nHour, int nMin, int nSec )
{
    // Store values in a SYSTEMTIME structure.
    SYSTEMTIME st = { 0 };
    st.wDay        = ( WORD )nDay;
    st.wHour    = ( WORD )nHour;
    st.wMinute    = ( WORD )nMin;
    st.wMonth    = ( WORD )nMonth;
    st.wSecond    = ( WORD )nSec;
    st.wYear    = ( WORD )nYear;

    // Make the conversion...
    m_status = valid;
    if ( ! ::SystemTimeToVariantTime( &st, &m_date ))
    {
        // Invalidate this.
        m_status = invalid;
        return FALSE;
    }
    return TRUE;
}

// Set the date.
BOOL CDateTime::SetDate( int nYear, int nMonth, int nDay )
{ 
    return SetDateTime( nYear, nMonth, nDay, 0, 0, 0 ); 
}

// Set the time.
BOOL CDateTime::SetTime( int nHour, int nMin, int nSec )
{ 
    return SetDateTime( 1899, 12, 30, nHour, nMin, nSec ); 
}

// Parse the given date/time string.
BOOL CDateTime::ParseDateTime( LPCTSTR pszDate, DWORD dwFlags /* = 0 */, LCID lcid /* = LANG_USER_DEFAULT */ )
{
    // Convert the input string to a DATE value.
    _bstr_t oleStr( pszDate );
    if ( ::VarDateFromStr( oleStr, lcid, dwFlags, &m_date ) != S_OK )
    {
        // Invalidate this.
        m_status = invalid;
        return FALSE;
    }
    return TRUE;
}

// Add a time.
void CDateTime::AddTime( int nDays, int nHours, int nMins, int nSecs )
{
    // Values in range?
    _ASSERT( nDays >= 0 && nDays <= 365 );
    _ASSERT( nHours >= 0 && nHours <= 23 );
    _ASSERT( nMins >= 0 && nMins <= 59 );
    _ASSERT( nSecs >= 0 && nSecs <= 59 );

    // Make the conversion...
    m_date += ( DATE )( nDays + ODT_HOURS( nHours ) + ODT_MINS( nMins ) + ODT_SECS( nSecs ));
}

// Subtract a time.
void CDateTime::SubTime( int nDays, int nHours, int nMins, int nSecs )
{
    // Values in range?
    _ASSERT( nDays >= 0 && nDays <= 365 );
    _ASSERT( nHours >= 0 && nHours <= 23 );
    _ASSERT( nMins >= 0 && nMins <= 59 );
    _ASSERT( nSecs >= 0 && nSecs <= 59 );

    // Make the conversion...
    m_date -= ( DATE )( nDays + ODT_HOURS( nHours ) + ODT_MINS( nMins ) + ODT_SECS( nSecs ));
}

// Obtain object status.
CDateTime::DtStatus CDateTime::GetStatus() const
{ 
    // Return the status value.
    return m_status; 
}

// Set the object status.
void CDateTime::SetStatus( DtStatus status )
{ 
    // Store the status value.
    m_status = status; 
}

// Set this to the DATE.
CDateTime& CDateTime::operator=( DATE dt )
{ 
    // Validate and set value.
    m_status = valid; 
    m_date = dt; 
    return *this; 
}

// Set this to the CDateTime.
CDateTime& CDateTime::operator=( const CDateTime& dtSrc )
{ 
    // Copy the state and value.
    m_status = dtSrc.m_status; 
    m_date = dtSrc.m_date; 
    return *this; 
}

// Set this to the DATE of the VARIANT.
CDateTime& CDateTime::operator=( const VARIANT& vt )
{
    // Is the variant of the correct type?
    m_status = valid;
    if ( vt.vt == VT_DATE )
        // Assign the value to this.
        m_date = vt.date;
    else if ( vt.vt == VT_EMPTY || vt.vt == VT_NULL )
        // Null this.
        m_status = null;
    else
    {
        // Create destination variant.
        VARIANTARG vtDest;
        vtDest.vt = VT_EMPTY;

        // Do the conversion.
        if ( ::VariantChangeType( &vtDest, const_cast< VARIANTARG * >( &vt ), 0, VT_DATE ) == S_OK )
            // Assign the result to this.
            // and validate us.
            m_date = vtDest.date;
        else
            // Invalidate this.
            m_status = invalid;
    }
    return *this;
}

// Add DATE to this.
CDateTime& CDateTime::operator+=( DATE dt )
{
    _ASSERT( m_status == valid );
    
    // Add the value to this.
    m_date += dt;
    return *this;
}

// Add DATE to this.
CDateTime CDateTime::operator+( DATE dt )
{
    _ASSERT( m_status == valid );
    
    // Add the value to this.
    return CDateTime( m_date + dt );
}

// Subract DATE from this.
CDateTime& CDateTime::operator-=( DATE dt )
{
    _ASSERT( m_status == valid );
    
    // Subtract the value from this.
    m_date -= dt;
    return *this;
}

// Subtract DATE from this.
CDateTime CDateTime::operator-( DATE dt )
{
    _ASSERT( m_status == valid );
    
    // Subtract the value from this.
    return CDateTime( m_date - dt );
}

// DATE >= this?
BOOL CDateTime::operator>=( DATE dt )
{ 
    _ASSERT( m_status == valid );
    return ( m_date >= dt ); 
}

// DATE <= this?
BOOL CDateTime::operator<=( DATE dt )
{ 
    _ASSERT( m_status == valid );
    return ( m_date <= dt ); 
}

// DATE > this?
BOOL CDateTime::operator>( DATE dt )
{ 
    _ASSERT( m_status == valid );
    return ( m_date > dt ); 
}

// DATE < this?
BOOL CDateTime::operator<( DATE dt )
{ 
    _ASSERT( m_status == valid );
    return ( m_date < dt ); 
}

// DATE equals this?
BOOL CDateTime::operator==( DATE dt )
{ 
    _ASSERT( m_status == valid );
    return ( m_date == dt ); 
}

// DATE differs this?
BOOL CDateTime::operator!=( DATE dt )
{ 
    _ASSERT( m_status == valid );
    return ( m_date != dt ); 
}
