//
//  MODULE: Ado2.cpp
//
//    AUTHOR: Carlos Antollini 
//
//  mailto: cantollini@hotmail.com
//
//    Date: 07/02/2003
//
//    Version 2.10
//
// ******************************************************************************
//
// Implementation for this class-library by Jan van den Baard. For the 
// implementation I have made a few changes in respect to the original
// version:
//
//    1) Made the classes UNICODE aware. They should compile into a UNICODE
//       aware app OK now.
//    2) Moved the ctor and dtor code out of the header (.h) file and into the
//       code (.cpp) file.
//    3) Added some extra error checking throughout the code.
//    4) All classes are inherited from "CADOBase" now. This is a simple
//       base class which encapsulates some shared functionality.
//    5) Removed ::CoInitialize() and ::CoUninitialize() calls. Client code
//       should take care of that.
//    6) Code now compiles under Warning level 4 without warnings.
//    7) Fixed some problems from the original classes like memory leaks, no
//       error handling in the class constructors etc.
//
// 02-Nov-2003 (JBa) - Initial ClassLib version.

#define _IMPORT_ADO_
#include "ado2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE 
static char THIS_FILE[] = __FILE__;
#endif  

#define ChunkSize 100

///////////////////////////////////////////////////////
//
// CJetEngine Class
//
BOOL CJetEngine::CCompactDatabase( CString strDatabaseSource, CString strDatabaseDestination )
{
    try
    {
        IJetEnginePtr jet( __uuidof( JetEngine ));
        return ( BOOL )( jet->CompactDatabase( _bstr_t( strDatabaseSource ), _bstr_t( strDatabaseDestination )) == S_OK );
    }
    catch( _com_error &e ) 
    {       
        e;
        return FALSE;
    } 
}

///////////////////////////////////////////////////////
//
// CADODatabase Class
//
CADODatabase::CADODatabase()
{
    m_strClassName        = _T( "CADODatabse" );
    m_nRecordsAffected    = 0;
    m_nConnectionTimeout    = 0;
    m_pConnection        = NULL;
    CADOBase::CheckHResult( m_pConnection.CreateInstance( __uuidof( Connection )));
}

CADODatabase::~CADODatabase()
{
    Close();
    if ( m_pConnection ) m_pConnection.Release();
}

DWORD CADODatabase::GetRecordCount( _RecordsetPtr m_pRs )
{
    DWORD numRows = m_pRs->GetRecordCount();
    if( numRows == 0xFFFFFFFF )
    {
        if( m_pRs->EndOfFile != VARIANT_TRUE )
            m_pRs->MoveFirst();

        while( m_pRs->EndOfFile != VARIANT_TRUE )
        {
            numRows++;
            m_pRs->MoveNext();
        }
        if( numRows > 0 )
            m_pRs->MoveFirst();
    }
    return numRows;
}

BOOL CADODatabase::Open( LPCTSTR lpstrConnection, LPCTSTR lpstrUserID, LPCTSTR lpstrPassword )
{
    _ASSERT_VALID( m_pConnection );
    if( IsOpen())
        Close();

    if( lpstrConnection != NULL && *lpstrConnection != _T( '\0' ))
        m_strConnection = lpstrConnection;

    _ASSERT( ! m_strConnection.IsEmpty());

    try
    {
        if( m_nConnectionTimeout != 0 )
            m_pConnection->PutConnectionTimeout( m_nConnectionTimeout );
        return ( BOOL )( m_pConnection->Open( _bstr_t( m_strConnection ), _bstr_t( lpstrUserID ), _bstr_t( lpstrPassword ), NULL ) == S_OK );
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }    
}


BOOL CADODatabase::IsOpen()
{
    if( m_pConnection )
        return m_pConnection->GetState() != adStateClosed;
    return FALSE;
}

void CADODatabase::Close()
{
    if( IsOpen())
        m_pConnection->Close();
}

///////////////////////////////////////////////////////
//
// CADORecordset Class
//
CADORecordset::CADORecordset()
{
    m_strClassName        = _T( "CADORecordset" );
    m_pRecordset        = NULL;
    m_pCmd            = NULL;
    m_dwLastError        = 0;
    m_pRecBinding        = NULL;
    m_nEditStatus        = CADORecordset::dbEditNone;
    m_nSearchDirection    = CADORecordset::searchForward;
    CADOBase::CheckHResult( m_pRecordset.CreateInstance( __uuidof( Recordset )));
    CADOBase::CheckHResult( m_pCmd.CreateInstance( __uuidof( Command )));
}

CADORecordset::CADORecordset( CADODatabase* pAdoDatabase )
{
    m_strClassName        = _T( "CADORecordset" );
    m_pRecordset        = NULL;
    m_pCmd            = NULL;
    m_dwLastError        = 0;
    m_pRecBinding        = NULL;
    m_nEditStatus        = CADORecordset::dbEditNone;
    m_nSearchDirection    = CADORecordset::searchForward;
    CADOBase::CheckHResult( m_pRecordset.CreateInstance( __uuidof( Recordset )));
    CADOBase::CheckHResult( m_pCmd.CreateInstance( __uuidof( Command )));
    m_pConnection = pAdoDatabase->GetActiveConnection();
}

CADORecordset::~CADORecordset()
{
    Close();
    if( m_pRecordset ) m_pRecordset.Release();
    if( m_pCmd       ) m_pCmd.Release();
}

BOOL CADORecordset::Open( _ConnectionPtr mpdb, LPCTSTR lpstrExec, int nOption )
{    
    _ASSERT_VALID( m_pRecordset );     
    Close();
    
    if ( lpstrExec != NULL && *lpstrExec != _T( '\0' ))
        m_strQuery = lpstrExec;

    _ASSERT( ! m_strQuery.IsEmpty());

    if( m_pConnection == NULL )
        m_pConnection = mpdb;

    //m_strQuery.TrimLeft();
    m_strQuery.Trim();
    BOOL bIsSelect = m_strQuery.Mid( 0, ( int )_tcslen( _T( "Select " ))).CompareNoCase( _T( "Select " )) == 0 && nOption == openUnknown;

    try
    {
        m_pRecordset->CursorType    = adOpenStatic;
        m_pRecordset->CursorLocation    = adUseClient;
        if( bIsSelect || nOption == openQuery || nOption == openUnknown )
            m_pRecordset->Open(( LPCSTR )m_strQuery, _variant_t(( IDispatch * )mpdb, TRUE ),
                            adOpenStatic, adLockOptimistic, adCmdUnknown );
        else if( nOption == openTable )
            m_pRecordset->Open(( LPCSTR )m_strQuery, _variant_t(( IDispatch * )mpdb, TRUE ), 
                            adOpenKeyset, adLockOptimistic, adCmdTable );
        else if( nOption == openStoredProc )
        {
            m_pCmd->ActiveConnection    = mpdb;
            m_pCmd->CommandText        = _bstr_t( m_strQuery );
            m_pCmd->CommandType        = adCmdStoredProc;
            m_pConnection->CursorLocation    = adUseClient;
            
            m_pRecordset = m_pCmd->Execute( NULL, NULL, adCmdText );
        }
        else
        {
            TRACE1( _T( "Unknown parameter. %d" ), nOption );
            return FALSE;
        }
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
    return m_pRecordset != NULL;
}

BOOL CADORecordset::Open( LPCTSTR lpstrExec, int nOption )
{
    _ASSERT( m_pConnection != NULL );
    _ASSERT( m_pConnection->GetState() != adStateClosed );
    return Open( m_pConnection, lpstrExec, nOption );
}

BOOL CADORecordset::OpenSchema( int nSchema, LPCTSTR SchemaID )
{
    try
    {
        _variant_t vtSchemaID = vtMissing;

        if( _tcslen( SchemaID ) != 0 )
            vtSchemaID = SchemaID;
            
        m_pRecordset = m_pConnection->OpenSchema(( enum SchemaEnum )nSchema, vtMissing, vtSchemaID );
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::Requery()
{
    _ASSERT_VALID( m_pRecordset );     
    if( IsOpen())
    {
        try
        {
            m_pRecordset->Requery( adExecuteRecord );
        }
        catch( _com_error &e )
        {
            dump_com_error( e );
            return FALSE;
        }
    }
    return TRUE;
}


BOOL CADORecordset::GetFieldValue( LPCTSTR lpFieldName, double& dbValue )
{    
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        switch( vtFld.vt )
        {
            case VT_R4:
                dbValue = vtFld.fltVal;
                break;

            case VT_R8:
                dbValue = vtFld.dblVal;
                break;

            case VT_DECIMAL:
                // Corrected by Jos� Carlos Mart�nez Gal�n
                dbValue = vtFld.decVal.Lo32;
                dbValue *= ( vtFld.decVal.sign == 128 )? -1 : 1;
                dbValue /= pow( 10, vtFld.decVal.scale ); 
                break;

            case VT_UI1:
                dbValue = vtFld.iVal;
                break;

            case VT_I2:
            case VT_I4:
                dbValue = vtFld.lVal;
                break;

            case VT_INT:
                dbValue = vtFld.intVal;
                break;

            case VT_EMPTY:
            case VT_NULL:
                dbValue = 0.0;
                break;

            default:
                dbValue = vtFld.dblVal;
                break;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( int nIndex, double& dbValue )
{    
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        dbValue = 0.0;
        _variant_t vtFld = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        switch( vtFld.vt )
        {
            case VT_R4:
                dbValue = vtFld.fltVal;
                break;

            case VT_R8:
                dbValue = vtFld.dblVal;
                break;

            case VT_DECIMAL:
                //Corrected by Jos� Carlos Mart�nez Gal�n
                dbValue = vtFld.decVal.Lo32;
                dbValue *= ( vtFld.decVal.sign == 128 )? -1 : 1;
                dbValue /= pow( 10, vtFld.decVal.scale ); 
                break;

            case VT_UI1:
                dbValue = vtFld.iVal;
                break;

            case VT_I2:
            case VT_I4:
                dbValue = vtFld.lVal;
                break;

            case VT_INT:
                dbValue = vtFld.intVal;
                break;

            case VT_EMPTY:
            case VT_NULL:
                dbValue = 0.0;
                break;

            default:
                dbValue = vtFld.dblVal;
                break;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( LPCTSTR lpFieldName, long& lValue )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        if( vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY )
            lValue = vtFld.lVal;
        else
            lValue = 0;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( int nIndex, long& lValue )
{
    _ASSERT_VALID( m_pRecordset );     

    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        if( vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY )
            lValue = vtFld.lVal;
        else
            lValue = 0;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( LPCTSTR lpFieldName, unsigned long& ulValue )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        if( vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY )
            ulValue = vtFld.ulVal;
        else
            ulValue = 0;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( int nIndex, unsigned long& ulValue )
{
    _ASSERT_VALID( m_pRecordset );     

    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        if( vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY )
            ulValue = vtFld.ulVal;
        else
            ulValue = 0;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( LPCTSTR lpFieldName, int& nValue )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        switch( vtFld.vt )
        {
            case VT_BOOL:
                nValue = vtFld.boolVal;
                break;

            case VT_I2:
            case VT_UI1:
                nValue = vtFld.iVal;
                break;

            case VT_INT:
                nValue = vtFld.intVal;
                break;

            case VT_NULL:
            case VT_EMPTY:
                nValue = 0;
                break;
            default:
                nValue = vtFld.iVal;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( int nIndex, int& nValue )
{
    _ASSERT_VALID( m_pRecordset );

    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        switch( vtFld.vt )
        {
            case VT_BOOL:
                nValue = vtFld.boolVal;
                break;

            case VT_I2:
            case VT_UI1:
                nValue = vtFld.iVal;
                break;

            case VT_INT:
                nValue = vtFld.intVal;
                break;

            case VT_NULL:
            case VT_EMPTY:
                nValue = 0;
                break;

            default:
                nValue = vtFld.iVal;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( LPCTSTR lpFieldName, CString& strValue, CString strDateFormat )
{
    _ASSERT_VALID( m_pRecordset );     

    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        switch( vtFld.vt ) 
        {
            case VT_R4:
                strValue = DblToStr( vtFld.fltVal );
                break;

            case VT_R8:
                strValue = DblToStr( vtFld.dblVal );
                break;

            case VT_BSTR:
                strValue = vtFld.bstrVal;
                break;

            case VT_I2:
            case VT_UI1:
                strValue = IntToStr( vtFld.iVal );
                break;

            case VT_INT:
                strValue = IntToStr( vtFld.intVal );
                break;

            case VT_I4:
                strValue = LongToStr( vtFld.lVal );
                break;

            case VT_UI4:
                strValue = ULongToStr( vtFld.ulVal );
                break;

            case VT_DECIMAL:
            {
                //Corrected by Jos� Carlos Mart�nez Gal�n
                double val = vtFld.decVal.Lo32;
                val *= ( vtFld.decVal.sign == 128 ) ? -1 : 1;
                val /= pow( 10, vtFld.decVal.scale ); 
                strValue = DblToStr( val );
                break;
            }

            case VT_DATE:
            {
                CDateTime dt( vtFld );
                if( strDateFormat.IsEmpty())
                    strDateFormat = _T( "%Y-%m-%d %H:%M:%S" );
                strValue = dt.Format( strDateFormat );
                break;
            }

            case VT_CY:
            {
                CCurrency cy( vtFld );
                strValue = cy.Format();
                break;
            }

            case VT_BOOL:
                strValue = vtFld.boolVal == VARIANT_TRUE ? _T( "True" ) : _T( "False" );
                break;

            default:
                strValue.Empty();
                return FALSE;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( int nIndex, CString& strValue, CString strDateFormat )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        switch( vtFld.vt )
        {
            case VT_R4:
                strValue = DblToStr( vtFld.fltVal );
                break;

            case VT_R8:
                strValue = DblToStr( vtFld.dblVal );
                break;

            case VT_BSTR:
                strValue = vtFld.bstrVal;
                break;

            case VT_I2:
            case VT_UI1:
                strValue = IntToStr( vtFld.iVal );
                break;

            case VT_INT:
                strValue = IntToStr( vtFld.intVal );
                break;

            case VT_I4:
                strValue = LongToStr( vtFld.lVal );
                break;

            case VT_UI4:
                strValue = ULongToStr( vtFld.ulVal );
                break;

            case VT_DECIMAL:
            {
                //Corrected by Jos� Carlos Mart�nez Gal�n
                double val = vtFld.decVal.Lo32;
                val *= ( vtFld.decVal.sign == 128 ) ? -1 : 1;
                val /= pow( 10, vtFld.decVal.scale ); 
                strValue = DblToStr( val );
                break;
            }

            case VT_DATE:
            {
                CDateTime dt( vtFld );
                if( strDateFormat.IsEmpty())
                    strDateFormat = _T( "%Y-%m-%d %H:%M:%S" );
                strValue = dt.Format( strDateFormat );
                break;
            }

            case VT_CY:
            {
                CCurrency cy( vtFld );
                strValue = cy.Format();
                break;
            }

            case VT_BOOL:
                strValue = vtFld.boolVal == VARIANT_TRUE ? _T( "True" ) : _T( "False" );
                break;

            default:
                strValue.Empty();
                return FALSE;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( LPCTSTR lpFieldName, CDateTime& time )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        switch( vtFld.vt ) 
        {
            case VT_DATE:
            {
                time = vtFld;
                break;
            }

            case VT_EMPTY:
            case VT_NULL:
                time.SetStatus( CDateTime::null );
                break;

            default:
                return FALSE;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( int nIndex, CDateTime& time )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        switch( vtFld.vt ) 
        {
            case VT_DATE:
            {
                time = vtFld;
                break;
            }

            case VT_EMPTY:
            case VT_NULL:
                time.SetStatus( CDateTime::null );
                break;

            default:
                return FALSE;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( LPCTSTR lpFieldName, bool& bValue )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        switch( vtFld.vt ) 
        {
            case VT_BOOL:
                bValue = vtFld.boolVal == VARIANT_TRUE ? true : false;
                break;

            case VT_EMPTY:
            case VT_NULL:
                bValue = false;
                break;

            default:
                return FALSE;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( int nIndex, bool& bValue )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        switch( vtFld.vt ) 
        {
            case VT_BOOL:
                bValue = vtFld.boolVal == VARIANT_TRUE ? true : false;
                break;

            case VT_EMPTY:
            case VT_NULL:
                bValue = false;
                break;

            default:
                return FALSE;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( LPCTSTR lpFieldName, CCurrency& cyValue )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        switch( vtFld.vt ) 
        {
            case VT_CY:
                cyValue = ( CURRENCY )vtFld.cyVal;
                break;

            case VT_EMPTY:
            case VT_NULL:
            {
                cyValue.SetStatus( CCurrency::null );
                break;
            }

            default:
                return FALSE;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( int nIndex, CCurrency& cyValue )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        switch( vtFld.vt ) 
        {
            case VT_CY:
                cyValue = ( CURRENCY )vtFld.cyVal;
                break;

            case VT_EMPTY:
            case VT_NULL:
            {
                cyValue.SetStatus( CCurrency::null );
                break;
            }

            default:
                return FALSE;
        }
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( LPCTSTR lpFieldName, _variant_t& vtValue )
{
    _ASSERT_VALID( m_pRecordset );     
    try
    {
        vtValue = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::GetFieldValue( int nIndex, _variant_t& vtValue )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        vtValue = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::IsFieldNull( LPCTSTR lpFieldName )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        return vtFld.vt == VT_NULL;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::IsFieldNull( int nIndex )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        return vtFld.vt == VT_NULL;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::IsFieldEmpty( LPCTSTR lpFieldName )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( lpFieldName )->Value;
        return vtFld.vt == VT_EMPTY || vtFld.vt == VT_NULL;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::IsFieldEmpty( int nIndex )
{
    _ASSERT_VALID( m_pRecordset );     
    
    try
    {
        _variant_t vtFld = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ))->Value;
        return vtFld.vt == VT_EMPTY || vtFld.vt == VT_NULL;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::SetFieldEmpty( LPCTSTR lpFieldName )
{
    _ASSERT_VALID( m_pRecordset );     
    _variant_t vtFld;
    vtFld.vt = VT_EMPTY;
    
    return PutFieldValue( lpFieldName, vtFld );
}

BOOL CADORecordset::SetFieldEmpty( int nIndex )
{
    _ASSERT_VALID( m_pRecordset );     
    _variant_t vtFld;
    vtFld.vt = VT_EMPTY;

    return PutFieldValue( _variant_t(( SHORT )nIndex ), vtFld );
}

DWORD CADORecordset::GetRecordCount()
{
    _ASSERT_VALID( m_pRecordset );     
    DWORD nRows = m_pRecordset->GetRecordCount();
    if( nRows == 0xFFFFFFFF )
    {
        nRows = 0;
        if( m_pRecordset->EndOfFile != VARIANT_TRUE )
            m_pRecordset->MoveFirst();
        
        while( m_pRecordset->EndOfFile != VARIANT_TRUE )
        {
            nRows++;
            m_pRecordset->MoveNext();
        }
        if( nRows > 0 )
            m_pRecordset->MoveFirst();
    }
    return nRows;
}

BOOL CADORecordset::IsOpen()
{
    if( m_pRecordset != NULL && IsConnectionOpen())
        return m_pRecordset->GetState() != adStateClosed;
    return FALSE;
}

void CADORecordset::Close()
{
    if( IsOpen())
    {
        if ( m_nEditStatus != dbEditNone )
              CancelUpdate();

        m_pRecordset->PutSort( _T("" ));
        m_pRecordset->Close();    
    }
}

BOOL CADODatabase::Execute( LPCTSTR lpstrExec )
{
    _ASSERT( m_pConnection != NULL );
    _ASSERT( lpstrExec != NULL && *lpstrExec != _T( '\0' ));

    _variant_t vRecords;
    m_nRecordsAffected = 0;

    try
    {
        m_pConnection->CursorLocation = adUseClient;
        m_pConnection->Execute( _bstr_t( lpstrExec ), &vRecords, adExecuteNoRecords );
        m_nRecordsAffected = vRecords.iVal;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;    
    }
}

BOOL CADORecordset::RecordBinding( CADORecordBinding &pAdoRecordBinding )
{
    _ASSERT_VALID( m_pRecordset );     
    m_pRecBinding = NULL;

    // Open the binding interface.
    CADOBase::CheckHResult( m_pRecordset->QueryInterface( __uuidof( IADORecordBinding ), ( LPVOID* )&m_pRecBinding ));
    
    // Bind the recordset to class
    CADOBase::CheckHResult( m_pRecBinding->BindToRecordset( &pAdoRecordBinding ));
    return TRUE;
}

BOOL CADORecordset::GetFieldInfo( LPCTSTR lpFieldName, StrADOFieldInfo* fldInfo )
{
    _ASSERT_VALID( m_pRecordset );     
    FieldPtr pField = m_pRecordset->Fields->GetItem( lpFieldName );
    return GetFieldInfo( pField, fldInfo );
}

BOOL CADORecordset::GetFieldInfo( int nIndex, StrADOFieldInfo* fldInfo )
{
    _ASSERT_VALID( m_pRecordset );     

    FieldPtr pField = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ));
    return GetFieldInfo( pField, fldInfo );
}

BOOL CADORecordset::GetFieldInfo( FieldPtr pField, StrADOFieldInfo* fldInfo )
{
    memset( fldInfo, 0, sizeof( StrADOFieldInfo ));
    _tcscpy( fldInfo->m_strName, ( LPCTSTR )pField->GetName());
    fldInfo->m_lDefinedSize = pField->GetDefinedSize();
    fldInfo->m_nType    = ( SHORT )pField->GetType();
    fldInfo->m_lAttributes    = pField->GetAttributes();
    if( ! IsEof())
        fldInfo->m_lSize = pField->GetActualSize();
    return TRUE;
}

BOOL CADORecordset::GetChunk( LPCTSTR lpFieldName, CString& strValue )
{
    _ASSERT_VALID( m_pRecordset );     
    FieldPtr pField = m_pRecordset->Fields->GetItem( lpFieldName );
    return GetChunk( pField, strValue );
}

BOOL CADORecordset::GetChunk( int nIndex, CString& strValue )
{
    _ASSERT_VALID( m_pRecordset );     

    FieldPtr pField = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ));
    return GetChunk( pField, strValue );
}

BOOL CADORecordset::GetChunk( FieldPtr pField, CString& strValue )
{
    CString str;
    long lngSize, lngOffSet = 0;
    _variant_t varChunk;

    lngSize = pField->ActualSize;
    
    str.Empty();
    while( lngOffSet < lngSize )
    { 
        try
        {
            varChunk = pField->GetChunk( ChunkSize );
            
            str       += varChunk.bstrVal;
            lngOffSet += ChunkSize;
        }
        catch( _com_error &e )
        {
            dump_com_error( e );
            return FALSE;
        }
    }

    lngOffSet = 0;
    strValue  = str;
    return TRUE;
}

BOOL CADORecordset::GetChunk( LPCTSTR lpFieldName, LPVOID lpData )
{
    _ASSERT_VALID( m_pRecordset );     
    FieldPtr pField = m_pRecordset->Fields->GetItem( lpFieldName );
    return GetChunk( pField, lpData );
}

BOOL CADORecordset::GetChunk( int nIndex, LPVOID lpData )
{
    _ASSERT_VALID( m_pRecordset );     

    FieldPtr pField = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ));
    return GetChunk( pField, lpData );
}

BOOL CADORecordset::GetChunk( FieldPtr pField, LPVOID lpData )
{
    long lngSize, lngOffSet = 0;
    _variant_t varChunk;    
    UCHAR chData;
    HRESULT hr;
    long lBytesCopied = 0;

    lngSize = pField->ActualSize;
    
    while( lngOffSet < lngSize )
    { 
        try
        {
            varChunk = pField->GetChunk( ChunkSize );

            // Copy the data only upto the Actual Size of Field.  
            for( long lIndex = 0; lIndex <= ( ChunkSize - 1 ); lIndex++ )
            {
                hr = SafeArrayGetElement( varChunk.parray, &lIndex, &chData );
                if( SUCCEEDED( hr ))
                {
                    // Take BYTE by BYTE and advance Memory Location
                    // hr = SafeArrayPutElement(( SAFEARRAY FAR * )lpData, &lBytesCopied ,&chData ); 
                    (( UCHAR * )lpData )[ lBytesCopied ] = chData;
                    lBytesCopied++;
                }
                else
                    break;
            }
            lngOffSet += ChunkSize;
        }
        catch( _com_error &e )
        {
            dump_com_error( e );
            return FALSE;
        }
    }

    lngOffSet = 0;
    return TRUE;
}

BOOL CADORecordset::AppendChunk( LPCTSTR lpFieldName, LPVOID lpData, UINT nBytes )
{
    _ASSERT_VALID( m_pRecordset );     
    FieldPtr pField = m_pRecordset->Fields->GetItem( lpFieldName );
    return AppendChunk( pField, lpData, nBytes );
}

BOOL CADORecordset::AppendChunk( int nIndex, LPVOID lpData, UINT nBytes )
{
    _ASSERT_VALID( m_pRecordset );     
    FieldPtr pField = m_pRecordset->Fields->GetItem( _variant_t(( SHORT )nIndex ));
    return AppendChunk( pField, lpData, nBytes );
}

BOOL CADORecordset::AppendChunk( FieldPtr pField, LPVOID lpData, UINT nBytes )
{
    HRESULT        hr;
    _variant_t     varChunk;
    long           lngOffset = 0;
    UCHAR           chData;
    SAFEARRAY FAR *psa = NULL;
    SAFEARRAYBOUND rgsabound[ 1 ];

    try
    {
        // Create a safe array to store the array of BYTES 
        rgsabound[ 0 ].lLbound = 0;
        rgsabound[ 0 ].cElements = nBytes;
        psa = SafeArrayCreate( VT_UI1, 1, rgsabound );
        if ( psa )
        {
            while( lngOffset < (long)nBytes )
            {
                chData    = (( UCHAR * )lpData )[ lngOffset ];
                hr = SafeArrayPutElement( psa, &lngOffset, &chData );
                if( FAILED( hr ))
                    return FALSE;
                
                lngOffset++;
            }
        }
        else
            return FALSE;
        lngOffset = 0;

        // Assign the Safe array  to a variant. 
        varChunk.vt     = VT_ARRAY | VT_UI1;
        varChunk.parray = psa;
        hr = pField->AppendChunk( varChunk );
        if( SUCCEEDED( hr )) return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
    return FALSE;
}

CString CADORecordset::GetString( LPCTSTR lpCols, LPCTSTR lpRows, LPCTSTR lpNull, long numRows )
{
    _ASSERT_VALID( m_pRecordset );     
    _bstr_t varOutput;
    _bstr_t varNull;
    _bstr_t varCols("\t");
    _bstr_t varRows("\r");

    if ( _tcslen( lpCols ) != 0 )
        varCols = _bstr_t( lpCols );

    if ( _tcslen( lpRows ) != 0 )
        varRows = _bstr_t( lpRows );
    
    if ( numRows == 0 )
        numRows = ( long )GetRecordCount();            
            
    varOutput = m_pRecordset->GetString( adClipString, numRows, varCols, varRows, varNull );
    //return ( LPCTSTR )varOutput;
    return CString(( LPCTSTR )varOutput );
}

CString IntToStr( int nVal )
{
    TCHAR buff[ 10 ];
    
    _itoa( nVal, buff, 10 );
    return CString( buff );
}

CString LongToStr( long lVal )
{
    TCHAR buff[ 20 ];
    
    _ltoa( lVal, buff, 10 );
    return CString( buff );
}

CString ULongToStr( unsigned long ulVal )
{
    TCHAR buff[ 20 ];
    
    _ultoa( ulVal, buff, 10 );
    return CString( buff );
}

CString DblToStr( double dblVal, int ndigits )
{
    char buff[ _CVTBUFSIZE ];

    // Unicode conversion done by CString class.
    _gcvt( dblVal, ndigits, buff );
    return CString( buff );
}

CString DblToStr( float fltVal )
{
    char buff[ _CVTBUFSIZE ];
    
    // Unicode conversion done by CString class.
    _gcvt( fltVal, 10, buff );
    return CString( buff );
}

void CADORecordset::Edit()
{
    m_nEditStatus = dbEdit;
}

BOOL CADORecordset::AddNew()
{
    _ASSERT_VALID( m_pRecordset );     
    m_nEditStatus = dbEditNone;
    try
    {
        m_pRecordset->AddNew();
        m_nEditStatus = dbEditNew;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::AddNew( CADORecordBinding &pAdoRecordBinding )
{
    _ASSERT_VALID( m_pRecBinding );     
    try
    {
        m_pRecBinding->AddNew( &pAdoRecordBinding );
        m_pRecBinding->Update( &pAdoRecordBinding );
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }    
}

BOOL CADORecordset::Update()
{
    _ASSERT_VALID( m_pRecordset );     
    if( m_nEditStatus != dbEditNone )
    {
        try
        {
            m_pRecordset->Update();
            return TRUE;
        }
        catch( _com_error &e )
        {
            m_pRecordset->CancelUpdate();
            dump_com_error( e );
            return FALSE;
        }
    }
    return TRUE;
}

void CADORecordset::CancelUpdate()
{
    _ASSERT_VALID( m_pRecordset );     
    m_pRecordset->CancelUpdate();
    m_nEditStatus = dbEditNone;
}

BOOL CADORecordset::SetFieldValue( int nIndex, const CString& strValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( _variant_t(( SHORT )nIndex ), _variant_t( strValue ));
}

BOOL CADORecordset::SetFieldValue( LPCTSTR lpFieldName, const CString& strValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( lpFieldName, _variant_t( strValue ));
}

BOOL CADORecordset::SetFieldValue( int nIndex, int nValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( _variant_t(( SHORT )nIndex ), _variant_t(( SHORT )nValue ));
}

BOOL CADORecordset::SetFieldValue( LPCTSTR lpFieldName, int nValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( lpFieldName, _variant_t(( SHORT )nValue ));
}

BOOL CADORecordset::SetFieldValue( int nIndex, long lValue )
{
    _ASSERT_VALID( m_pRecordset );         
    return PutFieldValue( _variant_t(( SHORT )nIndex ), _variant_t( lValue ));
}

BOOL CADORecordset::SetFieldValue( LPCTSTR lpFieldName, long lValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( lpFieldName, _variant_t( lValue ));
}

BOOL CADORecordset::SetFieldValue( int nIndex, unsigned long ulValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( _variant_t(( SHORT )nIndex ), _variant_t( ulValue ));
}

BOOL CADORecordset::SetFieldValue( LPCTSTR lpFieldName, unsigned long ulValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( lpFieldName, _variant_t( ulValue ));
}

BOOL CADORecordset::SetFieldValue( int nIndex, double dblValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( _variant_t(( SHORT )nIndex ), _variant_t( dblValue ));
}

BOOL CADORecordset::SetFieldValue( LPCTSTR lpFieldName, double dblValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( lpFieldName, _variant_t( dblValue ));
}

BOOL CADORecordset::SetFieldValue( int nIndex, const CDateTime& time )
{
    _ASSERT_VALID( m_pRecordset );
    if ( time.GetStatus() == CDateTime::invalid )
        return FALSE;
    return PutFieldValue( _variant_t(( SHORT )nIndex ), _variant_t(( DATE )time ));
}

BOOL CADORecordset::SetFieldValue( LPCTSTR lpFieldName, const CDateTime& time )
{
    _ASSERT_VALID( m_pRecordset );     
    if ( time.GetStatus() == CDateTime::invalid )
        return FALSE;
    return PutFieldValue( lpFieldName, _variant_t(( DATE )time ));
}

BOOL CADORecordset::SetFieldValue( int nIndex, bool bValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( _variant_t(( SHORT )nIndex ), _variant_t( bValue ));
}

BOOL CADORecordset::SetFieldValue( LPCTSTR lpFieldName, bool bValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( lpFieldName, _variant_t( bValue ));
}

BOOL CADORecordset::SetFieldValue( int nIndex, const CCurrency& cyValue )
{
    _ASSERT_VALID( m_pRecordset );     
    if( cyValue.GetStatus() == CCurrency::invalid )
        return FALSE;
    return PutFieldValue( _variant_t(( SHORT )nIndex ), _variant_t(( CURRENCY )cyValue ));
}

BOOL CADORecordset::SetFieldValue( LPCTSTR lpFieldName, const CCurrency& cyValue )
{
    _ASSERT_VALID( m_pRecordset );     
    if( cyValue.GetStatus() == CCurrency::invalid )
        return FALSE;
    return PutFieldValue( lpFieldName, _variant_t(( CURRENCY )cyValue ));
}

BOOL CADORecordset::SetFieldValue( int nIndex, const _variant_t& vtValue )
{
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( _variant_t(( SHORT )nIndex ), vtValue );
}

BOOL CADORecordset::SetFieldValue( LPCTSTR lpFieldName, const _variant_t& vtValue )
{    
    _ASSERT_VALID( m_pRecordset );     
    return PutFieldValue( lpFieldName, vtValue );
}


BOOL CADORecordset::SetBookmark()
{
    _ASSERT_VALID( m_pRecordset );     
    if( m_varBookmark.vt != VT_EMPTY )
    {
        m_pRecordset->Bookmark = m_varBookmark;
        return TRUE;
    }
    return FALSE;
}

BOOL CADORecordset::Delete()
{
    _ASSERT_VALID( m_pRecordset );     
    if( m_pRecordset->Delete( adAffectCurrent ) != S_OK )
        return FALSE;

    if( m_pRecordset->Update() != S_OK )
        return FALSE;
    
    m_nEditStatus = dbEditNone;
    return TRUE;
}

BOOL CADORecordset::Find( LPCTSTR lpFind, int nSearchDirection )
{
    _ASSERT_VALID( m_pRecordset );     
    m_strFind = lpFind;
    m_nSearchDirection = nSearchDirection;

    _ASSERT( ! m_strFind.IsEmpty());

    if( m_nSearchDirection == searchForward )
    {
        m_pRecordset->Find( _bstr_t( m_strFind ), 0, adSearchForward, _T( "" ));
        if( ! IsEof())
        {
            m_varBookFind = m_pRecordset->Bookmark;
            return TRUE;
        }
    }
    else if( m_nSearchDirection == searchBackward )
    {
        m_pRecordset->Find( _bstr_t( m_strFind ), 0, adSearchBackward, _T( "" ));
        if( ! IsBof())
        {
            m_varBookFind = m_pRecordset->Bookmark;
            return TRUE;
        }
    }
    else
    {
        TRACE1( _T( "Unknown parameter. %d" ), nSearchDirection );
        m_nSearchDirection = searchForward;
    }
    return FALSE;
}

BOOL CADORecordset::FindFirst( LPCTSTR lpFind )
{
    _ASSERT_VALID( m_pRecordset );     
    m_pRecordset->MoveFirst();
    return Find( lpFind );
}

BOOL CADORecordset::FindNext()
{
    _ASSERT_VALID( m_pRecordset );     
    if( m_nSearchDirection == searchForward )
    {
        m_pRecordset->Find( _bstr_t( m_strFind ), 1, adSearchForward, m_varBookFind );
        if( ! IsEof())
        {
            m_varBookFind = m_pRecordset->Bookmark;
            return TRUE;
        }
    }
    else
    {
        m_pRecordset->Find( _bstr_t( m_strFind ), 1, adSearchBackward, m_varBookFind );
        if( ! IsBof())
        {
            m_varBookFind = m_pRecordset->Bookmark;
            return TRUE;
        }
    }
    return FALSE;
}

BOOL CADORecordset::PutFieldValue( LPCTSTR lpFieldName, _variant_t vtFld )
{
    _ASSERT_VALID( m_pRecordset );     
    if( m_nEditStatus == dbEditNone )
        return FALSE;
    
    try
    {
        m_pRecordset->Fields->GetItem( lpFieldName )->Value = vtFld; 
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;    
    }
}


BOOL CADORecordset::PutFieldValue( _variant_t vtIndex, _variant_t vtFld )
{
    _ASSERT_VALID( m_pRecordset );     
    if( m_nEditStatus == dbEditNone )
        return FALSE;

    try
    {
        m_pRecordset->Fields->GetItem( vtIndex )->Value = vtFld;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::Clone( CADORecordset &pRs )
{
    _ASSERT_VALID( m_pRecordset );     
    try
    {
        pRs.m_pRecordset = m_pRecordset->Clone( adLockUnspecified );
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::SetFilter( LPCTSTR strFilter )
{
    _ASSERT_VALID( m_pRecordset );     
    _ASSERT( IsOpen());
    
    try
    {
        m_pRecordset->PutFilter( strFilter );
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::SetSort( LPCTSTR strCriteria )
{
    _ASSERT_VALID( m_pRecordset );     
    _ASSERT( IsOpen());
    
    try
    {
        m_pRecordset->PutSort( strCriteria );
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::SaveAsXML( LPCTSTR lpstrXMLFile )
{
    _ASSERT_VALID( m_pRecordset );     
    _ASSERT( IsOpen());
    
    try
    {
        return ( BOOL )( m_pRecordset->Save( lpstrXMLFile, adPersistXML ) == S_OK );
    }
    catch(_com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
    //return TRUE;
}

BOOL CADORecordset::OpenXML( LPCTSTR lpstrXMLFile )
{
    _ASSERT_VALID( m_pRecordset );     
    if( IsOpen())
        Close();

    try
    {
        return ( BOOL )( m_pRecordset->Open( lpstrXMLFile, _T( "Provider=MSPersist;" ), adOpenForwardOnly, adLockOptimistic, adCmdFile ) == S_OK );
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADORecordset::Execute( CADOCommand* pAdoCommand )
{
    _ASSERT_VALID( m_pRecordset );     
    if( IsOpen())
        Close();

    _ASSERT( ! pAdoCommand->GetText().IsEmpty());

    try
    {
        m_pConnection->CursorLocation = adUseClient;
        m_pRecordset = pAdoCommand->GetCommand()->Execute( NULL, NULL, pAdoCommand->GetType());
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

///////////////////////////////////////////////////////
//
// CADOCommand Class
//
CADOCommand::CADOCommand( CADODatabase* pAdoDatabase, const CString& strCommandText, int nCommandType )
{
    m_strClassName            = _T( "CADOCommand" );
    m_pCommand            = NULL;
    CADOBase::CheckHResult( m_pCommand.CreateInstance( __uuidof( Command )));
    m_strCommandText        = strCommandText;
    m_pCommand->CommandText        = ( LPCTSTR )m_strCommandText;
    m_nCommandType            = nCommandType;
    m_pCommand->CommandType        = ( CommandTypeEnum )m_nCommandType;
    m_pCommand->ActiveConnection    = pAdoDatabase->GetActiveConnection();    
    m_nRecordsAffected        = 0;
}

CADOCommand::~CADOCommand()
{
    if ( m_pCommand ) m_pCommand.Release();
}

BOOL CADOCommand::AddParameter( CADOParameter* pAdoParameter )
{
    _ASSERT_VALID( m_pCommand );     
    _ASSERT( pAdoParameter->GetParameter() != NULL );

    try
    {
        m_pCommand->Parameters->Append( pAdoParameter->GetParameter());
        return TRUE;
    }
    catch( _com_error& e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOCommand::AddParameter( const CString& strName, int nType, int nDirection, long lSize, int nValue )
{
    _ASSERT_VALID( m_pCommand );     
    _variant_t vtValue;

    vtValue.vt   = VT_I2;
    vtValue.iVal = ( SHORT )nValue;

    return AddParameter( strName, nType, nDirection, lSize, vtValue );
}

BOOL CADOCommand::AddParameter( const CString& strName, int nType, int nDirection, long lSize, long lValue )
{
    _ASSERT_VALID( m_pCommand );     
    _variant_t vtValue;

    vtValue.vt   = VT_I4;
    vtValue.lVal = lValue;

    return AddParameter( strName, nType, nDirection, lSize, vtValue );
}

BOOL CADOCommand::AddParameter( const CString& strName, int nType, int nDirection, long lSize, double dblValue, int nPrecision, int nScale)
{
    _ASSERT_VALID( m_pCommand );     
    _variant_t vtValue;

    vtValue.vt     = VT_R8;
    vtValue.dblVal = dblValue;

    return AddParameter( strName, nType, nDirection, lSize, vtValue, nPrecision, nScale );
}

BOOL CADOCommand::AddParameter( const CString& strName, int nType, int nDirection, long lSize, const CString& strValue )
{
    _ASSERT_VALID( m_pCommand );     
    _variant_t vtValue;

    vtValue = strValue;

    return AddParameter( strName, nType, nDirection, lSize, vtValue );
}

BOOL CADOCommand::AddParameter( const CString& strName, int nType, int nDirection, long lSize, const CDateTime& time )
{
    _ASSERT_VALID( m_pCommand );     
    _variant_t vtValue;

    vtValue.vt   = VT_DATE;
    vtValue.date = time;

    return AddParameter( strName, nType, nDirection, lSize, vtValue );
}

BOOL CADOCommand::AddParameter( const CString& strName, int nType, int nDirection, long lSize, const _variant_t& vtValue, int nPrecision, int nScale )
{
    _ASSERT_VALID( m_pCommand );     
    try
    {
        _bstr_t name( strName );
        _ParameterPtr pParam = m_pCommand->CreateParameter( name.GetBSTR(), ( ADODB::DataTypeEnum )nType, ( ParameterDirectionEnum )nDirection, lSize, vtValue );
        pParam->PutPrecision(( unsigned char )nPrecision );
        pParam->PutNumericScale(( unsigned char )nScale );
        m_pCommand->Parameters->Append( pParam );
        return TRUE;
    }
    catch( _com_error& e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

void CADOCommand::SetText( const CString& strCommandText )
{
    _ASSERT_VALID( m_pCommand );     
    _ASSERT( ! strCommandText.IsEmpty());

    m_strCommandText = strCommandText;
    m_pCommand->CommandText = ( LPCTSTR )m_strCommandText;
}

void CADOCommand::SetType( int nCommandType )
{
    _ASSERT_VALID( m_pCommand );     
    m_nCommandType = nCommandType;
    m_pCommand->CommandType = ( CommandTypeEnum )m_nCommandType;
}

BOOL CADOCommand::Execute()
{
    _ASSERT_VALID( m_pCommand );     
    _variant_t vRecords;
    m_nRecordsAffected = 0;
    try
    {
        m_pCommand->Execute( &vRecords, NULL, adCmdStoredProc );
        m_nRecordsAffected = vRecords.iVal;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

///////////////////////////////////////////////////////
//
// CADOParameter Class
//
CADOParameter::CADOParameter( int nType, long lSize, int nDirection, const CString& strName)
{
    m_strClassName        = _T( "CADOParameter" );
    m_pParameter        = NULL;
    CADOBase::CheckHResult( m_pParameter.CreateInstance( __uuidof( Parameter )));
    m_pParameter->Direction = ( ParameterDirectionEnum )nDirection;
    m_strName        = strName;
    m_pParameter->Name    = ( LPCTSTR )m_strName;
    m_pParameter->Type    = ( ADODB::DataTypeEnum )nType;
    m_pParameter->Size    = lSize;
    m_nType            = nType;
}

CADOParameter::~CADOParameter()
{
    if ( m_pParameter ) m_pParameter.Release();
}

BOOL CADOParameter::SetValue( int nValue )
{
    _ASSERT_VALID( m_pParameter );     
    _variant_t vtVal;

    _ASSERT( m_pParameter != NULL );
    
    vtVal.vt   = VT_I2;
    vtVal.iVal = ( SHORT )nValue;

    try
    {
        if( m_pParameter->Size == 0 )
            m_pParameter->Size = sizeof( int );

        m_pParameter->Value = vtVal;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::SetValue( long lValue )
{
    _ASSERT_VALID( m_pParameter );     
    _variant_t vtVal;

    _ASSERT( m_pParameter != NULL );
    
    vtVal.vt   = VT_I4;
    vtVal.lVal = lValue;

    try
    {
        if( m_pParameter->Size == 0 )
            m_pParameter->Size = sizeof( long );

        m_pParameter->Value = vtVal;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::SetValue( double dblValue )
{
    _ASSERT_VALID( m_pParameter );     
    _variant_t vtVal;

    _ASSERT( m_pParameter != NULL );
    
    vtVal.vt     = VT_R8;
    vtVal.dblVal = dblValue;

    try
    {
        if( m_pParameter->Size == 0 )
            m_pParameter->Size = sizeof( double );

        m_pParameter->Value = vtVal;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::SetValue( const CString& strValue)
{
    _ASSERT_VALID( m_pParameter );     
    _variant_t vtVal;

    _ASSERT( m_pParameter != NULL );
    
    if( strValue.IsEmpty())
        vtVal.vt = VT_NULL;
    else
        vtVal = strValue;

    try
    {
        if( m_pParameter->Size == 0 )
            m_pParameter->Size = sizeof( TCHAR  ) * strValue.GetStringLength();

        m_pParameter->Value = vtVal;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::SetValue( const CDateTime& time )
{
    _ASSERT_VALID( m_pParameter );     
    _variant_t vtVal;

    _ASSERT( m_pParameter != NULL );
    
    vtVal.vt   = VT_DATE;
    vtVal.date = time;

    try
    {
        if( m_pParameter->Size == 0 )
            m_pParameter->Size = sizeof( DATE );

        m_pParameter->Value = vtVal;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::SetValue( const _variant_t& vtValue )
{
    _ASSERT_VALID( m_pParameter );     

    try
    {
        if( m_pParameter->Size == 0 )
            m_pParameter->Size = sizeof( VARIANT );
        
        m_pParameter->Value = vtValue;
        return TRUE;
    }
    catch( _com_error &e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::GetValue( int& nValue )
{
    _ASSERT_VALID( m_pParameter );     
    _variant_t vtVal;
    int nVal = 0;

    try
    {
        vtVal = m_pParameter->Value;

        switch( vtVal.vt )
        {
            case VT_BOOL:
                nVal = vtVal.boolVal;
                break;

            case VT_I2:
            case VT_UI1:
                nVal = vtVal.iVal;
                break;

            case VT_INT:
                nVal = vtVal.intVal;
                break;

            case VT_NULL:
            case VT_EMPTY:
                nVal = 0;
                break;

            default:
                nVal = vtVal.iVal;
        }    
        nValue = nVal;
        return TRUE;
    }
    catch( _com_error& e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::GetValue( long& lValue )
{
    _ASSERT_VALID( m_pParameter );     
    _variant_t vtVal;
    long lVal = 0;

    try
    {
        vtVal = m_pParameter->Value;
        if( vtVal.vt != VT_NULL && vtVal.vt != VT_EMPTY )
            lVal = vtVal.lVal;
        lValue = lVal;
        return TRUE;
    }
    catch( _com_error& e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::GetValue( double& dbValue )
{
    _ASSERT_VALID( m_pParameter );     
    _variant_t vtVal;
    double dblVal;
    try
    {
        vtVal = m_pParameter->Value;
        switch( vtVal.vt )
        {
            case VT_R4:
                dblVal = vtVal.fltVal;
                break;

            case VT_R8:
                dblVal = vtVal.dblVal;
                break;

            case VT_DECIMAL:
                // Corrected by Jos� Carlos Mart�nez Gal�n
                dblVal = vtVal.decVal.Lo32;
                dblVal *= ( vtVal.decVal.sign == 128 )? -1 : 1;
                dblVal /= pow( 10, vtVal.decVal.scale ); 
                break;

            case VT_UI1:
                dblVal = vtVal.iVal;
                break;

            case VT_I2:
            case VT_I4:
                dblVal = vtVal.lVal;
                break;

            case VT_INT:
                dblVal = vtVal.intVal;
                break;

            case VT_NULL:
            case VT_EMPTY:
                dblVal = 0;
                break;

            default:
                dblVal = 0;
        }
        dbValue = dblVal;
        return TRUE;
    }
    catch( _com_error& e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::GetValue( CString& strValue, CString strDateFormat )
{
    _ASSERT_VALID( m_pParameter );     
    _variant_t vtVal;
    CString strVal;

    try
    {
        vtVal = m_pParameter->Value;
        switch( vtVal.vt ) 
        {
            case VT_R4:
                strVal = DblToStr(vtVal.fltVal);
                break;

            case VT_R8:
                strVal = DblToStr(vtVal.dblVal);
                break;

            case VT_BSTR:
                strVal = vtVal.bstrVal;
                break;

            case VT_I2:
            case VT_UI1:
                strVal = IntToStr(vtVal.iVal);
                break;

            case VT_INT:
                strVal = IntToStr(vtVal.intVal);
                break;

            case VT_I4:
                strVal = LongToStr(vtVal.lVal);
                break;

            case VT_DECIMAL:
            {
                // Corrected by Jos� Carlos Mart�nez Gal�n
                double val = vtVal.decVal.Lo32;
                val *= ( vtVal.decVal.sign == 128 ) ? -1 : 1;
                val /= pow( 10, vtVal.decVal.scale ); 
                strVal = DblToStr( val );
                break;
            }

            case VT_DATE:
            {
                CDateTime dt( vtVal );

                if( strDateFormat.IsEmpty())
                    strDateFormat = _T( "%Y-%m-%d %H:%M:%S" );
                strVal = dt.Format( strDateFormat );
                break;
            }

            case VT_EMPTY:
            case VT_NULL:
                strVal.Empty();
                break;
            
            default:
                strVal.Empty();
                return FALSE;
        }
        strValue = strVal;
        return TRUE;
    }
    catch( _com_error& e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::GetValue( CDateTime& time )
{
    _ASSERT_VALID( m_pParameter );     
    _variant_t vtVal;

    try
    {
        vtVal = m_pParameter->Value;
        switch( vtVal.vt ) 
        {
            case VT_DATE:
            {
                CDateTime dt( vtVal );
                time = dt;
                break;
            }

            case VT_EMPTY:
            case VT_NULL:
                time.SetStatus( CDateTime::null );
                break;

            default:
                return FALSE;
        }
        return TRUE;
    }
    catch( _com_error& e )
    {
        dump_com_error( e );
        return FALSE;
    }
}

BOOL CADOParameter::GetValue( _variant_t& vtValue )
{
    _ASSERT_VALID( m_pParameter );     
    try
    {
        vtValue = m_pParameter->Value;
        return TRUE;
    }
    catch( _com_error& e )
    {
        dump_com_error( e );
        return FALSE;
    }
}
///////////////////////////////////////////////////////
//
// CADOException Class
//
CADOException::CADOException( int nCause, const CString& strErrorString )
{
    m_nCause = nCause;
    m_sDescription = strErrorString;
}

CADOException::~CADOException()
{
}

int CADOException::GetError( int nADOError )
{
    switch ( nADOError )
    {
        case noError:
            return CADOException::noError;
            break;

        default:
            return CADOException::Unknown;
    }    
}

void CThrowADOException( int nADOError, CString strErrorString )
{
    throw new CADOException( nADOError, strErrorString );
}
