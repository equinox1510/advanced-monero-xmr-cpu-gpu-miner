#ifndef _RGBHLS_H_
#define _RGBHLS_H_
//
// rgbhls.h
//
// Replaced by color.h
//

#include "color.h"

#define CRGBHLS CColor

#endif // _RGBHLS_H_
