#ifndef _BOYERMOORE_H_
#define _BOYERMOORE_H_
//
// boyermoore.h
//
// (C) Copyright 2000-2001 Jan van den Baard.
//     All Rights Reserved.
//

#include "../standard.h"
#include "../strings/string.h"

// A class that implements the boyer-moore search,
// algorithm for forward and backward searches.
class CBoyerMoore
{
public:
    // Construction, destruction.
    CBoyerMoore();
    CBoyerMoore( const CBoyerMoore& bm );
    CBoyerMoore( LPCSTR pszSearchString, BOOL bCaseOn = FALSE );
    virtual ~CBoyerMoore();

    // Implementation.
    int FindForward( char *pData, int nLength );
    int FindBackward( char *pData, int nLength );
    inline void SetSearchString( LPCSTR pszSearchString ) { _ASSERT_VALID( pszSearchString ); m_strSearchString = pszSearchString; SetSearchString(); }
    inline void SetCaseMode( BOOL bCase = TRUE ) { m_bCaseOn = bCase; SetSearchString(); }
    
    // Operator overloads.
    const CBoyerMoore& operator=( const CBoyerMoore& bm );
    const CBoyerMoore& operator=( LPCSTR pszSearchString );
protected:
    // Helpers.
    void SetSearchString();

    // Data.
    CString    m_strSearchString;
    BOOL        m_bCaseOn;
    int        m_aDeltas[ 256 ];
    int        m_aBackDeltas[ 256 ];
};

#endif _BOYERMOORE_H_
