#ifndef _RECTTRACKER_H_
#define _RECTTRACKER_H_
//
// recttracker.h
//
// (C) Copyright 2002 Jan van den Baard.
//     All Rights Reserved.
//

#include "tracker.h"
#include "../gdi/dc.h"
#include "../gdi/pen.h"

// Show a rectange during mouse-tracking.
class CRectTracker : public CTracker
{
    _NO_COPY( CRectTracker );
public:
    // Rectangle rendering types.
    enum
    { 
        rttSolid = 0,
        rttHatched = 1
    };

    // Construction/destruction.
    CRectTracker();
    virtual ~CRectTracker();

    // Implementation.
    void SetRectStyle( int nStyle );
    void GetTrackedRect( CWindow *pWindow, CRect& rcRect, BOOL bClient = FALSE );

protected:
    // Overidables.
    virtual BOOL OnMouseButton( CWindow *pWindow, UINT uMsg );
    virtual BOOL OnTrackEnter( CWindow *pWindow );
    virtual void OnTrackExit( CWindow *pWindow );
    virtual BOOL OnTrackMove( CWindow *pWindow );
    
    // Helpers.
    void SetRectSize( LPSIZE lpSize );
    void DrawRect( CWindow *pWindow );
    void Rectangle();
    void ComputeRect( CWindow *pWindow );
    
    // Data.
    CDC        m_DC;
    CRect        m_rcRect;
    CPoint    m_ptCurrPos;
    BOOL        m_bVisible;
    BOOL        m_bTracking;
    int        m_nStyle;
    int        m_nOldROP2;
};

#endif // _RECTTRACKER_H_
