#ifndef _MDIWINDOW_H_
#define _MDIWINDOW_H_
//
// mdiwindow.h
//
// (C) Copyright 2000-2001 Jan van den Baard.
//     All Rights Reserved.
//

#include "window.h"
#include "../menus/menu.h"
#include "../collectors/array.h"

// Forward declarations.
class CMDIMainWindow;

// A "CWindow" derived class which the functionality of a multiple
// document interface (MDI) child window.
class CMDIChildWindow : public CWindow
{
    _NO_COPY( CMDIChildWindow );
public:
    // Friends.
    friend class CApp;

    // Construction/destruction.
    CMDIChildWindow();
    virtual ~CMDIChildWindow();

    // Implementation.
    BOOL Create( LPCTSTR lpszWindowName, DWORD dwStyle, int x, int y, int nWidth, int nHeight, CMDIMainWindow *pFrame );
    BOOL Create( LPCTSTR lpszWindowName, DWORD dwStyle, const CRect& crBounds, CMDIMainWindow *pFrame );
    void MDIDestroy();
    void MDIActivate();
    void MDIMaximize();
    void MDIRestore();

protected:
    // Overidables.
    virtual LRESULT WindowProc( UINT uMsg, WPARAM wParam, LPARAM lParam );
    virtual LRESULT OnMDIActivated( CWindow *pDeactivated );
    virtual LRESULT OnMDIDeactivated( CWindow *pActivated );
    virtual LRESULT OnMDINCCreate( LPCREATESTRUCT pCS );

    // Default MDI child message handling procedure.
    static LRESULT CALLBACK StaticMDIChildProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

    // Data.
    CMDIMainWindow *m_pMainWindow;
};

// A "CWindow" derived class with functionality for a multiple
// document interface (MDI) frame window.
class CMDIMainWindow : public CWindow
{
    _NO_COPY( CMDIMainWindow );
public:
    // Friends.
    friend class CMDIChildWindow;

    // Construction destruction.
    CMDIMainWindow();
    virtual ~CMDIMainWindow();

    // Implementation.
    void MDIActivate( CWindow *pWnd );
    CMDIChildWindow *MDIGetActive( LPBOOL pbMaximized = NULL ) const;
    void MDIIconArrange();
    void MDIMaximize( CWindow *pWnd );
    void MDINext();
    void MDIPred();
    void MDIRestore( CWindow *pWnd );
    CMenu *MDISetMenu( CMenu *pFrameMenu, CMenu *pWindowMenu );
    void MDITile( UINT nFlags = MDITILE_HORIZONTAL | MDITILE_SKIPDISABLED );
    void MDICascade( UINT nFlags = MDITILE_SKIPDISABLED );
    void SetBaseID( UINT nBaseID = 0x0BAD );
    CWindow *GetMDIClient();
    UINT MDINumChilds() const;
    
protected:
    // Overidable.
    virtual LRESULT OnCreate( LPCREATESTRUCT pCS );
    virtual void OnMDIChildRemoved( CMDIChildWindow *pWnd );
    virtual BOOL PreTranslateMessage( LPMSG pMsg );

    // Helpers.
    BOOL AddChild( CMDIChildWindow *pChild );
    BOOL RemChild( CMDIChildWindow *pChild );
    
    // Used to track children.
    struct MDIChild
    {
        CMDIChildWindow *m_pChild;
    };

    // Data.
    CWindow            m_Client;
    CSimpleArray<MDIChild>    m_Children;
    UINT                m_nBaseID;
};

// Inlined functions (MDI Child).
inline void CMDIChildWindow::MDIActivate()
{ _ASSERT_VALID( GetSafeHWND()); _ASSERT_VALID( m_pMainWindow ); m_pMainWindow->GetMDIClient()->SendMessage( WM_MDIACTIVATE, ( WPARAM )GetSafeHWND()); }
inline void CMDIChildWindow::MDIMaximize()
{ _ASSERT_VALID( GetSafeHWND()); _ASSERT_VALID( m_pMainWindow ); m_pMainWindow->GetMDIClient()->SendMessage( WM_MDIMAXIMIZE, ( WPARAM )GetSafeHWND()); }
inline void CMDIChildWindow::MDIRestore()
{ _ASSERT_VALID( GetSafeHWND()); _ASSERT_VALID( m_pMainWindow ); m_pMainWindow->GetMDIClient()->SendMessage( WM_MDIRESTORE, ( WPARAM )GetSafeHWND()); }
inline void CMDIChildWindow::MDIDestroy()
{ _ASSERT_VALID( GetSafeHWND()); _ASSERT_VALID( m_pMainWindow ); m_pMainWindow->GetMDIClient()->SendMessage( WM_MDIDESTROY, ( WPARAM )GetSafeHWND()); }

// Inlined functions (MDI Main).
// Activate an MDI child window.
inline void CMDIMainWindow::MDIActivate( CWindow *pWnd )
{ _ASSERT_VALID( GetSafeHWND()); _ASSERT_VALID( pWnd );    m_Client.SendMessage( WM_MDIACTIVATE, ( WPARAM )pWnd->GetSafeHWND()); }
inline void CMDIMainWindow::MDIIconArrange()
{ _ASSERT_VALID( GetSafeHWND()); m_Client.SendMessage( WM_MDIICONARRANGE ); }
inline void CMDIMainWindow::MDIMaximize( CWindow *pWnd )
{ _ASSERT_VALID( GetSafeHWND()); _ASSERT_VALID( pWnd ); m_Client.SendMessage( WM_MDIMAXIMIZE, ( WPARAM )( pWnd->GetSafeHWND())); }
inline void CMDIMainWindow::MDINext()
{ _ASSERT_VALID( GetSafeHWND()); m_Client.SendDlgItemMessage( WM_MDINEXT, NULL, FALSE ); }
inline void CMDIMainWindow::MDIPred()
{ _ASSERT_VALID( GetSafeHWND()); m_Client.SendDlgItemMessage( WM_MDINEXT, NULL, TRUE ); }
inline void CMDIMainWindow::MDIRestore( CWindow *pWnd )
{ _ASSERT_VALID( GetSafeHWND()); _ASSERT_VALID( pWnd ); m_Client.SendMessage( WM_MDIRESTORE, ( WPARAM )( pWnd->GetSafeHWND())); }
inline void CMDIMainWindow::MDITile( UINT nFlags /* = MDITILE_HORIZONTAL | MDITILE_SKIPDISABLED */ )
{ _ASSERT_VALID( GetSafeHWND()); m_Client.SendMessage( WM_MDITILE, ( WPARAM )nFlags ); }
inline void CMDIMainWindow::MDICascade( UINT nFlags /* = MDITILE_SKIPDISABLED */ )
{ _ASSERT_VALID( GetSafeHWND()); m_Client.SendMessage( WM_MDICASCADE, ( WPARAM )nFlags ); }
inline void CMDIMainWindow::SetBaseID( UINT nBaseID /* = 0x0BAD */ )
{ m_nBaseID = nBaseID; }
inline CWindow *CMDIMainWindow::GetMDIClient()
{ return &m_Client; }
inline UINT CMDIMainWindow::MDINumChilds() const
{ return m_Children.GetSize(); }

#endif // _MDIWINDOW_H_
