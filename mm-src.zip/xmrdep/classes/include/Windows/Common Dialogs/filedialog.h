#ifndef _FILEDIALOG_H_
#define _FILEDIALOG_H_
//
// filedialog.h
//
// (C) Copyright 2000 Jan van den Baard.
//     All Rights Reserved.
//

#include "commondialog.h"
#include "../../strings/string.h"

// A wrapper for the File common dialog.
class CFileDialog : public CCommonDialog
{
    _NO_COPY( CFileDialog );
public:
    // Constructor.
    CFileDialog()
    {
        // Default the data.
        m_pszFilters   = NULL;
        m_nFilterIndex = 0;
    }

    // Destructor.
    virtual ~CFileDialog()
    {;}

    // Interface.
    inline LPCTSTR& Filters()
    { return ( LPCTSTR& )m_pszFilters; }
    inline int& FilterIndex()
    { return ( int& )m_nFilterIndex; }
    inline CString& Caption()
    { return ( CString& )m_strCaption; }
    inline CString& DefExt()
    { return ( CString& )m_strDefExt; }
    inline CString& Dir()
    { return ( CString& )m_strDir; }
    BOOL DoModal( CWindow *parent, LPCTSTR pszDir, LPCTSTR pszFile, BOOL bOpenDialog = TRUE, DWORD dwFlags = 0, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT );
    int GetName( int nPrev, CString& str ) const;

protected:
    // Hook procedure. This will attach the dialog
    // to the object.
    static UINT_PTR CALLBACK HookProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

    // Routes the CDN_xxx messages to their virtual handlers.
    virtual LRESULT OnNotify( LPNMHDR pNMHDR );

    // Overidable. Called just before the dialog is opened.
    virtual BOOL PreShowDialog( LPOPENFILENAME pOpenFileName )
    { return TRUE; }

    // Overidables.
    virtual LRESULT OnFileOK( LPOFNOTIFY pOFNotify )
    { return 0; }
    virtual LRESULT OnFolderChange( LPOFNOTIFY pOFNotify )
    { return 0; }
    virtual LRESULT OnHelp( LPOFNOTIFY pOFNotify )
    { return 0; }
    virtual LRESULT OnInitDone( LPOFNOTIFY pOFNotify )
    { return 0; }
    virtual LRESULT OnSelChange( LPOFNOTIFY pOFNotify )
    { return 0; }
    virtual LRESULT OnShareViolation( LPOFNOTIFY pOFNotify )
    { return OFN_SHAREWARN; }
    virtual LRESULT OnTypeChange( LPOFNOTIFY pOFNotify )
    { return 0; }

    // Data.
    LPCTSTR        m_pszFilters;
    int        m_nFilterIndex;
    CString    m_strCaption;
    CString    m_strDefExt;
    CString    m_strDir;
    CString    m_strFile;
};

#endif // _FILEDIALOG_H_
