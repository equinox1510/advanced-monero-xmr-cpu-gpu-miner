#ifndef _CONTROLS_ALL_H_
#define _CONTROLS_ALL_H_
//
// all.h
//
// (C) Copyright 1999-2003 Jan van den Baard
//     All Rights Reserved.
//

#include "button.h"
#include "checkbox.h"
#include "combobox.h"
#include "edit.h"
#include "listbox.h"
#include "radiobutton.h"
#include "scroller.h"
#include "static.h"
#include "richedit.h"

#endif // _CONTROLS_ALL_