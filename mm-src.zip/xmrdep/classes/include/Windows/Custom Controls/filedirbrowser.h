#ifndef _FILEDIRBROWSER_H_
#define _FILEDIRBROWSER_H_
//
// filedirbrowser.h
//
// (C) Copyright 2002 Jan van den Baard.
//     All Rights Reserved.
//

#include "browser.h"
#include "../../strings/string.h"

// A CEdit derived class which enables the user
// to enter text and push a selection button to drop
// a "CFileDirTree" control for file or directory
// selection.
class CFileDirBrowser : public CBrowser
{
    _NO_COPY( CFileDirBrowser );
public:
    // Constructor.
    CFileDirBrowser();

    // Destructor.
    virtual ~CFileDirBrowser() {;}

    // Implementation.
    inline CString& BasePath()
    { return ( CString& )m_sBasePath; }
    inline CString& LoadingText()
    { return ( CString& )m_sLoadingText; }
    inline CString& Filters()
    { return ( CString& )m_sFilters; }
    inline COLORREF& LoadingTextColor()
    { return ( COLORREF& )m_crLoadingTextColor; }
    inline BOOL& ShowFiles()
    { return ( BOOL& )m_bShowFiles; }

protected:
    // Overidables.
    virtual void GetButtonSize( CDC *pDC, CSize& sButtonSize );
    virtual void RenderButton( CDC *pDC, CRect rcClip );
    virtual void OnBrowserClicked();
    virtual void OnFileDropped( HDROP hDrop );

    // Data.
    CString    m_sBasePath;
    CString    m_sLoadingText;
    CString    m_sFilters;
    COLORREF    m_crLoadingTextColor;
    BOOL        m_bShowFiles;
};

#endif // _FILEDIRBROWSER_H_
