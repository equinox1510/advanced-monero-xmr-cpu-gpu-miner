#ifndef _COLORPICKER_H_
#define _COLORPICKER_H_
//
// colorpicker.h
//
// (C) Copyright 2000 Jan van den Baard.
//     All Rights Reserved.
//

#include "hotbutton.h"

// Notifications.
#define COLPN_COLORCHANGED    WM_USER+0xDEAD

// A CHotButton derived class which enables the user
// to select colors.
class CColorPicker : public CHotButton
{
    _NO_COPY( CColorPicker );
public:
    // Constructor.
    CColorPicker();

    // Destructor.
    virtual ~CColorPicker();

    // Implementation.
    inline COLORREF& Color() { return ( COLORREF& )m_crColor; }
    inline BOOL& FullOpen() { return ( BOOL& )m_bFullOpen; }
    inline BOOL& DropDownArrow() { return ( BOOL& )m_bRenderArrow; }
    inline void SetXPStyle( BOOL bPopup = TRUE, BOOL bControl = TRUE ) { m_bXPPopup = bPopup; m_bXPControl = bControl; }
    inline CString& DefaultString() { return ( CString& )m_strDefault; }
    inline CString& CustomString() { return ( CString& )m_strCustom; }

protected:
    // Overidables.
    virtual LRESULT WindowProc( UINT uMsg, WPARAM wParam, LPARAM lParam );
    virtual void Trigger();
    virtual BOOL TipString( LPNMTTDISPINFO lpDispInfo );
    virtual LRESULT OnPaint( CDC *pDC );
    virtual LRESULT OnEraseBkgnd( CDC *pDC )
    { return 1; }

    // For the layout engine.
    virtual BOOL OnGetMinSize( CSize& szMinSize );

    // Helpers.
    void PaintControl( CDC *pDC );

    // Data.
    COLORREF    m_crColor;
    COLORREF    m_crTempColor;
    BOOL        m_bFullOpen;
    BOOL        m_bRenderArrow;
    BOOL        m_bXPPopup;
    BOOL        m_bXPControl;
    BOOL        m_bIsDropped;
    CString    m_strTip;
    CString    m_strDefault;
    CString    m_strCustom;
};

#endif // _COLORPICKER_H_
