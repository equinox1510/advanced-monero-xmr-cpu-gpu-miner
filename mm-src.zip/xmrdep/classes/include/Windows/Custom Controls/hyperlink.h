#ifndef _HYPERLINK_H_
#define _HYPERLINK_H_
//
// hyperlink.h
//
// (C) Copyright 2000 Jan van den Baard.
//     All Rights Reserved.
//

#include "hotbutton.h"
#include "../../gdi/bitmap.h"
#include "../../strings/string.h"

// A CHotButton derived class which can be used
// to display a click-able hyperlink in your UI.
class CHyperLink : public CHotButton
{
    _NO_COPY( CHyperLink );
public:
    // Constructor.
    CHyperLink();

    // Destructor.
    virtual ~CHyperLink();

    // Possible image place.
    enum { IMPLACE_LEFT = 0, IMPLACE_TOP, IMPLACE_RIGHT, IMPLACE_BOTTOM };
    
    // Implementation.
    void VisitURL() { Trigger(); }
    inline UINT& ImagePlace()
    { return ( UINT& )m_nImagePlace; }
    inline CString& URL()
    { return ( CString& )m_strURL; }

    inline COLORREF& NormalColor()
    { return ( COLORREF& )m_crNormal; }

    inline COLORREF& VisitedColor()
    { return ( COLORREF& )m_crVisited; }

    inline COLORREF& HotColor()
    { return ( COLORREF& )m_crHot; }

    inline BOOL& IsVisited() 
    { return ( BOOL& )m_bIsVisited; }

protected:
    // Overidables.
    virtual void Trigger();
    virtual BOOL TipString( LPNMTTDISPINFO lpDispInfo );
    virtual LRESULT OnPaint( CDC *pDC );
    virtual LRESULT WindowProc( UINT uMsg, WPARAM wParam, LPARAM lParam );
    virtual LRESULT OnEraseBkgnd( CDC *pDC )
    { return 1; }

    // Helpers.
    void PaintControl( CDC *pDC );

    // For the layout engine.
    virtual BOOL OnGetMinSize( CSize& szMinSize );

    // Data.
    CFont        m_urlFont;
    CString    m_strURL;
    COLORREF    m_crNormal;
    COLORREF    m_crVisited;
    COLORREF    m_crHot;
    HCURSOR        m_curHand;
    UINT        m_nImagePlace;
    BOOL        m_bIsVisited;
};

#endif // _HYPERLINK_H_
