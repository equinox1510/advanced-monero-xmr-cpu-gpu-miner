//
// mdichildwindow.cpp
//
// (C) Copyright 2000-2001 Jan van den Baard.
//     All Rights Reserved.
//

#include "mdiwindow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// As defined in "window.cpp".
extern CLinkedList<CWindow>        global_window_list;
extern CWindow *CFindObjectByHandle( CLinkedList<CWindow>& list, HWND hWnd );

// Constructor.
CMDIChildWindow::CMDIChildWindow()
{
    // Default data.
    m_pMainWindow = NULL;
}

// Destructor.
CMDIChildWindow::~CMDIChildWindow()
{
}

// Create MDI child.
BOOL CMDIChildWindow::Create(    LPCTSTR lpszWindowName, DWORD dwStyle, const CRect& crBounds, CMDIMainWindow *pFrame )
{
    _ASSERT( GetSafeHWND() == NULL );
    _ASSERT_VALID( pFrame );

    // Create us.
    MDICREATESTRUCT mdcs;
    mdcs.x        = crBounds.Left();
    mdcs.y        = crBounds.Top();
    mdcs.cx        = crBounds.Width();
    mdcs.cy        = crBounds.Height();
    mdcs.hOwner    = CGetInstanceHandle();
    mdcs.style    = dwStyle;
    mdcs.szClass    = _T( "CMDIChildClass" );
    mdcs.szTitle    = lpszWindowName;
    mdcs.lParam    = ( LPARAM )this;

    HWND hWnd = ( HWND )pFrame->m_Client.SendMessage( WM_MDICREATE, 0, ( LPARAM )&mdcs );
    if ( hWnd )
    {
        // Add us to the frame.
        pFrame->AddChild( this );

        // Store frame.
        m_pMainWindow = pFrame;
        return TRUE;
    }
    return FALSE;
}

// Create MDI child.
BOOL CMDIChildWindow::Create(    LPCTSTR lpszWindowName, DWORD dwStyle, int x, int y, int nWidth, int nHeight, CMDIMainWindow *pFrame )
{
    return Create( lpszWindowName, dwStyle, CRect( x, y, x + nWidth, y + nHeight ), pFrame );
}

// Called when activated.
LRESULT CMDIChildWindow::OnMDIActivated( CWindow *pDeactivated )
{
    return 0;
}

// Called when deactivated.
LRESULT CMDIChildWindow::OnMDIDeactivated( CWindow *pActivated )
{
    return 0;
}

// Called by the window procedure.
LRESULT CMDIChildWindow::OnMDINCCreate( LPCREATESTRUCT pCS )
{
    return TRUE;
}

// Window procedure override.
LRESULT CMDIChildWindow::WindowProc( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    // Get message.
    switch ( uMsg )
    {
        // Activation change?
        case    WM_MDIACTIVATE:
        {
            // Call the appropiate override.
            if ( GetSafeHWND() == ( HWND )wParam      ) return OnMDIDeactivated( lParam ? CFindObjectByHandle( global_window_list, ( HWND )lParam ) : NULL );
            else if ( GetSafeHWND() == ( HWND )lParam ) return OnMDIActivated(   wParam ? CFindObjectByHandle( global_window_list, ( HWND )wParam ) : NULL );
            break;
        }
    
        case    WM_DESTROY:
        {
            // Remove us from the array.
            if ( m_pMainWindow )
                m_pMainWindow->RemChild( this );
            break;
        }
    }


    // Call the default MDI procedure.
    return DefMDIChildProc( GetSafeHWND(), uMsg, wParam, lParam );
}

// Default MDI child procedure.
LRESULT CALLBACK CMDIChildWindow::StaticMDIChildProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    // What's the message...
    switch ( uMsg )
    {
        // We capture the WM_NCCREATE message here to link the window handle
        // to it's owner object.
        case    WM_NCCREATE:
        {
            // Get the MDICREATESTRUCT pointer.
            LPMDICREATESTRUCT pmcs = ( LPMDICREATESTRUCT )(( LPCREATESTRUCT )lParam )->lpCreateParams;
            _ASSERT_VALID( pmcs );

            // Attach the handle to it's owner object.
            _ASSERT_VALID( pmcs->lParam );
            if ( ! (( CMDIChildWindow * )pmcs->lParam )->Attach( hWnd, TRUE ))
                return FALSE;

            // Call the OnMDINCCreate() override.
            if ((( CMDIChildWindow * )pmcs->lParam )->OnMDINCCreate(( LPCREATESTRUCT )lParam ) == FALSE )
                return FALSE;
        }
    }

    // Call the default message handler.
    return DefMDIChildProc( hWnd, uMsg, wParam, lParam );
}
